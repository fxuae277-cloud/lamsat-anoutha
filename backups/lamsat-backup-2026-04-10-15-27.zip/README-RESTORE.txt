==============================================
  دليل استعادة النسخة الاحتياطية - لمسة أنوثة ERP
  Backup Restore Guide - Lamsat Onoutha ERP
==============================================

المحتويات:
  /database/dump.sql       - نسخة قاعدة البيانات PostgreSQL
  /database/data.json      - نسخة البيانات بصيغة JSON (احتياطي)
  /uploads/                - الصور والملفات المرفوعة
  /config/                 - إعدادات النظام
  metadata.json            - معلومات النسخة الاحتياطية
  README-RESTORE.txt       - هذا الملف

=============================================
  خطوات الاستعادة على خادم Hetzner
=============================================

1) نقل الملف إلى الخادم:
   scp lamsat-backup-YYYY-MM-DD-HH-mm.zip user@your-server:/tmp/

2) فك الضغط:
   cd /tmp
   unzip lamsat-backup-YYYY-MM-DD-HH-mm.zip -d lamsat-restore

3) استعادة قاعدة البيانات:
   # إنشاء قاعدة بيانات جديدة (اختياري)
   sudo -u postgres createdb lamsat_erp

   # استعادة من dump.sql
   sudo -u postgres psql lamsat_erp < /tmp/lamsat-restore/database/dump.sql

   # أو باستخدام DATABASE_URL
   psql $DATABASE_URL < /tmp/lamsat-restore/database/dump.sql

4) استعادة الملفات المرفوعة:
   cp -r /tmp/lamsat-restore/uploads/* /path/to/your/app/uploads/

5) متغيرات البيئة المطلوبة:
   DATABASE_URL=postgresql://user:password@localhost:5432/lamsat_erp
   SESSION_SECRET=your-secret-key
   PORT=5000
   NODE_ENV=production

6) تشغيل التطبيق:
   npm install
   npm run build
   npm start

=============================================
  ملاحظات مهمة
=============================================
- تأكد من أن PostgreSQL مثبت (الإصدار 14 أو أحدث)
- النسخة تشمل جميع الجداول والبيانات
- كلمات المرور مشفرة ولا تحتاج إعادة تعيين
- في حال فشل dump.sql، استخدم data.json للاستعادة اليدوية
