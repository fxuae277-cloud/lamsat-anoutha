--
-- PostgreSQL database dump
--

\restrict 6pfgwZJVcd6FJ5UYZbaTGNuv53oLTbJ1CTxT0yCUSQd3meUbUaZeWFDHi89yIvU

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.warehouses DROP CONSTRAINT IF EXISTS warehouses_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.supplier_ocr_templates DROP CONSTRAINT IF EXISTS supplier_ocr_templates_supplier_id_suppliers_id_fk;
ALTER TABLE IF EXISTS ONLY public.stocktakes DROP CONSTRAINT IF EXISTS stocktakes_location_id_locations_id_fk;
ALTER TABLE IF EXISTS ONLY public.stocktakes DROP CONSTRAINT IF EXISTS stocktakes_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.stocktakes DROP CONSTRAINT IF EXISTS stocktakes_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.stocktakes DROP CONSTRAINT IF EXISTS stocktakes_approved_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.stocktake_items DROP CONSTRAINT IF EXISTS stocktake_items_stocktake_id_stocktakes_id_fk;
ALTER TABLE IF EXISTS ONLY public.stocktake_items DROP CONSTRAINT IF EXISTS stocktake_items_product_id_products_id_fk;
ALTER TABLE IF EXISTS ONLY public.stock_transfers DROP CONSTRAINT IF EXISTS stock_transfers_to_location_id_locations_id_fk;
ALTER TABLE IF EXISTS ONLY public.stock_transfers DROP CONSTRAINT IF EXISTS stock_transfers_from_location_id_locations_id_fk;
ALTER TABLE IF EXISTS ONLY public.stock_transfers DROP CONSTRAINT IF EXISTS stock_transfers_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.stock_transfer_lines DROP CONSTRAINT IF EXISTS stock_transfer_lines_variant_id_product_variants_id_fk;
ALTER TABLE IF EXISTS ONLY public.stock_transfer_lines DROP CONSTRAINT IF EXISTS stock_transfer_lines_transfer_id_stock_transfers_id_fk;
ALTER TABLE IF EXISTS ONLY public.shifts DROP CONSTRAINT IF EXISTS shifts_cashier_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.shifts DROP CONSTRAINT IF EXISTS shifts_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_shift_id_shifts_id_fk;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_customer_id_customers_id_fk;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_cashier_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.sale_returns DROP CONSTRAINT IF EXISTS sale_returns_shift_id_shifts_id_fk;
ALTER TABLE IF EXISTS ONLY public.sale_returns DROP CONSTRAINT IF EXISTS sale_returns_sale_id_sales_id_fk;
ALTER TABLE IF EXISTS ONLY public.sale_returns DROP CONSTRAINT IF EXISTS sale_returns_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.sale_returns DROP CONSTRAINT IF EXISTS sale_returns_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.sale_return_items DROP CONSTRAINT IF EXISTS sale_return_items_sale_item_id_sale_items_id_fk;
ALTER TABLE IF EXISTS ONLY public.sale_return_items DROP CONSTRAINT IF EXISTS sale_return_items_return_id_sale_returns_id_fk;
ALTER TABLE IF EXISTS ONLY public.sale_return_items DROP CONSTRAINT IF EXISTS sale_return_items_product_id_products_id_fk;
ALTER TABLE IF EXISTS ONLY public.sale_items DROP CONSTRAINT IF EXISTS sale_items_sale_id_sales_id_fk;
ALTER TABLE IF EXISTS ONLY public.sale_items DROP CONSTRAINT IF EXISTS sale_items_product_id_products_id_fk;
ALTER TABLE IF EXISTS ONLY public.purchase_items DROP CONSTRAINT IF EXISTS purchase_items_purchase_id_purchase_invoices_id_fk;
ALTER TABLE IF EXISTS ONLY public.purchase_items DROP CONSTRAINT IF EXISTS purchase_items_product_id_products_id_fk;
ALTER TABLE IF EXISTS ONLY public.purchase_invoices DROP CONSTRAINT IF EXISTS purchase_invoices_supplier_id_suppliers_id_fk;
ALTER TABLE IF EXISTS ONLY public.purchase_invoices DROP CONSTRAINT IF EXISTS purchase_invoices_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.purchase_invoices DROP CONSTRAINT IF EXISTS purchase_invoices_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.purchase_extra_costs DROP CONSTRAINT IF EXISTS purchase_extra_costs_purchase_invoice_id_purchase_invoices_id_f;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_category_id_categories_id_fk;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.product_variants DROP CONSTRAINT IF EXISTS product_variants_product_id_products_id_fk;
ALTER TABLE IF EXISTS ONLY public.payroll_runs DROP CONSTRAINT IF EXISTS payroll_runs_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.payroll_runs DROP CONSTRAINT IF EXISTS payroll_runs_approved_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.payroll_details DROP CONSTRAINT IF EXISTS payroll_details_payroll_id_payroll_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.payroll_details DROP CONSTRAINT IF EXISTS payroll_details_employee_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_shift_id_shifts_id_fk;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_employee_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_product_id_products_id_fk;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_order_id_orders_id_fk;
ALTER TABLE IF EXISTS ONLY public.locations DROP CONSTRAINT IF EXISTS locations_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.location_transfers DROP CONSTRAINT IF EXISTS location_transfers_to_location_id_locations_id_fk;
ALTER TABLE IF EXISTS ONLY public.location_transfers DROP CONSTRAINT IF EXISTS location_transfers_from_location_id_locations_id_fk;
ALTER TABLE IF EXISTS ONLY public.location_transfers DROP CONSTRAINT IF EXISTS location_transfers_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.location_transfers DROP CONSTRAINT IF EXISTS location_transfers_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.location_transfer_items DROP CONSTRAINT IF EXISTS location_transfer_items_transfer_id_location_transfers_id_fk;
ALTER TABLE IF EXISTS ONLY public.location_transfer_items DROP CONSTRAINT IF EXISTS location_transfer_items_product_id_products_id_fk;
ALTER TABLE IF EXISTS ONLY public.location_inventory DROP CONSTRAINT IF EXISTS location_inventory_product_id_products_id_fk;
ALTER TABLE IF EXISTS ONLY public.location_inventory DROP CONSTRAINT IF EXISTS location_inventory_location_id_locations_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory DROP CONSTRAINT IF EXISTS inventory_warehouse_id_warehouses_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_transfers DROP CONSTRAINT IF EXISTS inventory_transfers_to_warehouse_id_warehouses_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_transfers DROP CONSTRAINT IF EXISTS inventory_transfers_product_id_products_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_transfers DROP CONSTRAINT IF EXISTS inventory_transfers_from_warehouse_id_warehouses_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_transfers DROP CONSTRAINT IF EXISTS inventory_transfers_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_transactions DROP CONSTRAINT IF EXISTS inventory_transactions_to_location_id_locations_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_transactions DROP CONSTRAINT IF EXISTS inventory_transactions_product_id_products_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_transactions DROP CONSTRAINT IF EXISTS inventory_transactions_from_location_id_locations_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_transactions DROP CONSTRAINT IF EXISTS inventory_transactions_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_transactions DROP CONSTRAINT IF EXISTS inventory_transactions_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory DROP CONSTRAINT IF EXISTS inventory_product_id_products_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_ledger DROP CONSTRAINT IF EXISTS inventory_ledger_variant_id_product_variants_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_ledger DROP CONSTRAINT IF EXISTS inventory_ledger_location_id_locations_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_ledger DROP CONSTRAINT IF EXISTS inventory_ledger_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_balances DROP CONSTRAINT IF EXISTS inventory_balances_variant_id_product_variants_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_balances DROP CONSTRAINT IF EXISTS inventory_balances_location_id_locations_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_adjustments DROP CONSTRAINT IF EXISTS inventory_adjustments_stocktake_id_stocktakes_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_adjustments DROP CONSTRAINT IF EXISTS inventory_adjustments_product_id_products_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_adjustments DROP CONSTRAINT IF EXISTS inventory_adjustments_location_id_locations_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_adjustments DROP CONSTRAINT IF EXISTS inventory_adjustments_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.inventory_adjustments DROP CONSTRAINT IF EXISTS inventory_adjustments_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_shift_id_shifts_id_fk;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.employees DROP CONSTRAINT IF EXISTS employees_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.employee_deductions DROP CONSTRAINT IF EXISTS employee_deductions_employee_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.employee_deductions DROP CONSTRAINT IF EXISTS employee_deductions_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.employee_deductions DROP CONSTRAINT IF EXISTS employee_deductions_applied_in_payroll_id_payroll_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.employee_advances DROP CONSTRAINT IF EXISTS employee_advances_settled_in_payroll_id_payroll_runs_id_fk;
ALTER TABLE IF EXISTS ONLY public.employee_advances DROP CONSTRAINT IF EXISTS employee_advances_employee_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.employee_advances DROP CONSTRAINT IF EXISTS employee_advances_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.cities DROP CONSTRAINT IF EXISTS cities_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.cash_ledger DROP CONSTRAINT IF EXISTS cash_ledger_shift_id_shifts_id_fk;
ALTER TABLE IF EXISTS ONLY public.cash_ledger DROP CONSTRAINT IF EXISTS cash_ledger_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.cash_ledger DROP CONSTRAINT IF EXISTS cash_ledger_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.bank_ledger DROP CONSTRAINT IF EXISTS bank_ledger_shift_id_shifts_id_fk;
ALTER TABLE IF EXISTS ONLY public.bank_ledger DROP CONSTRAINT IF EXISTS bank_ledger_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.bank_ledger DROP CONSTRAINT IF EXISTS bank_ledger_branch_id_branches_id_fk;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_branch_id_branches_id_fk;
DROP TRIGGER IF EXISTS validate_expense_shift ON public.expenses;
DROP TRIGGER IF EXISTS trg_sale_items_set_total ON public.sale_items;
DROP TRIGGER IF EXISTS trg_sale_items_apply_inventory ON public.sale_items;
DROP TRIGGER IF EXISTS trg_orders_set_order_number ON public.orders;
DROP TRIGGER IF EXISTS sales_set_invoice_number ON public.sales;
DROP TRIGGER IF EXISTS bi_orders_set_order_number ON public.orders;
DROP INDEX IF EXISTS public.uq_location_product;
DROP INDEX IF EXISTS public."IDX_session_expire";
ALTER TABLE IF EXISTS ONLY public.warehouses DROP CONSTRAINT IF EXISTS warehouses_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_unique;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.suppliers DROP CONSTRAINT IF EXISTS suppliers_pkey;
ALTER TABLE IF EXISTS ONLY public.suppliers DROP CONSTRAINT IF EXISTS suppliers_name_unique;
ALTER TABLE IF EXISTS ONLY public.supplier_ocr_templates DROP CONSTRAINT IF EXISTS supplier_ocr_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.stocktakes DROP CONSTRAINT IF EXISTS stocktakes_pkey;
ALTER TABLE IF EXISTS ONLY public.stocktake_items DROP CONSTRAINT IF EXISTS stocktake_items_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_transfers DROP CONSTRAINT IF EXISTS stock_transfers_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_transfer_lines DROP CONSTRAINT IF EXISTS stock_transfer_lines_pkey;
ALTER TABLE IF EXISTS ONLY public.shifts DROP CONSTRAINT IF EXISTS shifts_pkey;
ALTER TABLE IF EXISTS ONLY public.session DROP CONSTRAINT IF EXISTS session_pkey;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_pkey;
ALTER TABLE IF EXISTS ONLY public.sale_returns DROP CONSTRAINT IF EXISTS sale_returns_pkey;
ALTER TABLE IF EXISTS ONLY public.sale_return_items DROP CONSTRAINT IF EXISTS sale_return_items_pkey;
ALTER TABLE IF EXISTS ONLY public.sale_items DROP CONSTRAINT IF EXISTS sale_items_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_items DROP CONSTRAINT IF EXISTS purchase_items_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_invoices DROP CONSTRAINT IF EXISTS purchase_invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_extra_costs DROP CONSTRAINT IF EXISTS purchase_extra_costs_pkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_pkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_barcode_unique;
ALTER TABLE IF EXISTS ONLY public.product_variants DROP CONSTRAINT IF EXISTS product_variants_sku_unique;
ALTER TABLE IF EXISTS ONLY public.product_variants DROP CONSTRAINT IF EXISTS product_variants_pkey;
ALTER TABLE IF EXISTS ONLY public.product_variants DROP CONSTRAINT IF EXISTS product_variants_barcode_unique;
ALTER TABLE IF EXISTS ONLY public.payroll_runs DROP CONSTRAINT IF EXISTS payroll_runs_pkey;
ALTER TABLE IF EXISTS ONLY public.payroll_details DROP CONSTRAINT IF EXISTS payroll_details_pkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_pkey;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_pkey;
ALTER TABLE IF EXISTS ONLY public.locations DROP CONSTRAINT IF EXISTS locations_pkey;
ALTER TABLE IF EXISTS ONLY public.location_transfers DROP CONSTRAINT IF EXISTS location_transfers_pkey;
ALTER TABLE IF EXISTS ONLY public.location_transfer_items DROP CONSTRAINT IF EXISTS location_transfer_items_pkey;
ALTER TABLE IF EXISTS ONLY public.location_inventory DROP CONSTRAINT IF EXISTS location_inventory_pkey;
ALTER TABLE IF EXISTS ONLY public.inventory_transfers DROP CONSTRAINT IF EXISTS inventory_transfers_pkey;
ALTER TABLE IF EXISTS ONLY public.inventory_transactions DROP CONSTRAINT IF EXISTS inventory_transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.inventory DROP CONSTRAINT IF EXISTS inventory_pkey;
ALTER TABLE IF EXISTS ONLY public.inventory_ledger DROP CONSTRAINT IF EXISTS inventory_ledger_pkey;
ALTER TABLE IF EXISTS ONLY public.inventory_balances DROP CONSTRAINT IF EXISTS inventory_balances_pkey;
ALTER TABLE IF EXISTS ONLY public.inventory_adjustments DROP CONSTRAINT IF EXISTS inventory_adjustments_pkey;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_pkey;
ALTER TABLE IF EXISTS ONLY public.employees DROP CONSTRAINT IF EXISTS employees_pkey;
ALTER TABLE IF EXISTS ONLY public.employee_deductions DROP CONSTRAINT IF EXISTS employee_deductions_pkey;
ALTER TABLE IF EXISTS ONLY public.employee_advances DROP CONSTRAINT IF EXISTS employee_advances_pkey;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_pkey;
ALTER TABLE IF EXISTS ONLY public.cities DROP CONSTRAINT IF EXISTS cities_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.cash_ledger DROP CONSTRAINT IF EXISTS cash_ledger_pkey;
ALTER TABLE IF EXISTS ONLY public.branches DROP CONSTRAINT IF EXISTS branches_pkey;
ALTER TABLE IF EXISTS ONLY public.bank_ledger DROP CONSTRAINT IF EXISTS bank_ledger_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
DROP TABLE IF EXISTS public.warehouses;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.suppliers;
DROP TABLE IF EXISTS public.supplier_ocr_templates;
DROP TABLE IF EXISTS public.stocktakes;
DROP TABLE IF EXISTS public.stocktake_items;
DROP TABLE IF EXISTS public.stock_transfers;
DROP TABLE IF EXISTS public.stock_transfer_lines;
DROP TABLE IF EXISTS public.shifts;
DROP TABLE IF EXISTS public.session;
DROP TABLE IF EXISTS public.sales;
DROP TABLE IF EXISTS public.sale_returns;
DROP TABLE IF EXISTS public.sale_return_items;
DROP TABLE IF EXISTS public.sale_items;
DROP TABLE IF EXISTS public.purchase_items;
DROP TABLE IF EXISTS public.purchase_invoices;
DROP TABLE IF EXISTS public.purchase_extra_costs;
DROP TABLE IF EXISTS public.products;
DROP TABLE IF EXISTS public.product_variants;
DROP TABLE IF EXISTS public.payroll_runs;
DROP TABLE IF EXISTS public.payroll_details;
DROP TABLE IF EXISTS public.orders;
DROP TABLE IF EXISTS public.order_items;
DROP TABLE IF EXISTS public.locations;
DROP TABLE IF EXISTS public.location_transfers;
DROP TABLE IF EXISTS public.location_transfer_items;
DROP TABLE IF EXISTS public.location_inventory;
DROP TABLE IF EXISTS public.inventory_transfers;
DROP TABLE IF EXISTS public.inventory_transactions;
DROP TABLE IF EXISTS public.inventory_ledger;
DROP TABLE IF EXISTS public.inventory_balances;
DROP TABLE IF EXISTS public.inventory_adjustments;
DROP TABLE IF EXISTS public.inventory;
DROP TABLE IF EXISTS public.expenses;
DROP TABLE IF EXISTS public.employees;
DROP TABLE IF EXISTS public.employee_deductions;
DROP TABLE IF EXISTS public.employee_advances;
DROP TABLE IF EXISTS public.customers;
DROP TABLE IF EXISTS public.cities;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.cash_ledger;
DROP TABLE IF EXISTS public.branches;
DROP TABLE IF EXISTS public.bank_ledger;
DROP TABLE IF EXISTS public.audit_log;
DROP FUNCTION IF EXISTS public.trg_validate_expense_shift();
DROP FUNCTION IF EXISTS public.trg_sales_set_invoice_number();
DROP FUNCTION IF EXISTS public.trg_orders_set_order_number();
DROP FUNCTION IF EXISTS public.sale_items_set_total();
DROP FUNCTION IF EXISTS public.sale_items_apply_inventory_and_update_sale();
DROP FUNCTION IF EXISTS public.pos_pay_order_by_pin(p_order_id integer, p_terminal_name text, p_pin text, p_payment_method text, p_bank_txn_id text, p_bank_receipt_image text);
DROP FUNCTION IF EXISTS public.pos_pay_order_by_pin(p_order_id integer, p_terminal_name text, p_pin text, p_payment_method text);
DROP FUNCTION IF EXISTS public.pos_open_shift_by_pin(p_terminal_code text, p_pin text, p_opening_cash numeric);
DROP FUNCTION IF EXISTS public.pos_get_open_shift_by_pin(p_terminal_code text, p_pin text);
DROP FUNCTION IF EXISTS public.pos_create_order_by_pin(p_terminal_name text, p_pin text, p_customer_name text, p_customer_phone text, p_city text, p_address text, p_delivery_type text, p_notes text, p_total numeric);
DROP FUNCTION IF EXISTS public.pos_close_shift_by_pin_v2(p_terminal_name text, p_pin text, p_closing_cash numeric);
DROP FUNCTION IF EXISTS public.pos_close_shift_by_pin(p_terminal_code text, p_pin text, p_closing_cash numeric);
DROP FUNCTION IF EXISTS public.pay_order(p_order_id integer, p_terminal_name text, p_pin text, p_payment_method text, p_bank_txn_id text, p_bank_receipt_image text);
DROP FUNCTION IF EXISTS public.pay_order(p_order_id integer, p_payment_method text, p_bank_txn_id text, p_bank_receipt_image text);
DROP FUNCTION IF EXISTS public.next_order_number(p_branch_id integer, p_terminal_name text);
DROP FUNCTION IF EXISTS public.get_open_shift_for_terminal(p_terminal_name text);
DROP FUNCTION IF EXISTS public.generate_invoice_number(p_branch_id integer, p_terminal_code text);
DROP FUNCTION IF EXISTS public.gen_order_number(p_branch_id integer, p_terminal_name text);
DROP FUNCTION IF EXISTS public.close_shift_cash(p_shift_id integer, p_closing_cash numeric);
DROP FUNCTION IF EXISTS public.close_shift(p_shift_id integer, p_cashier_id integer, p_counted_cash numeric);
--
-- Name: close_shift(integer, integer, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.close_shift(p_shift_id integer, p_cashier_id integer, p_counted_cash numeric) RETURNS TABLE(out_shift_id integer, out_total_paid numeric, out_counted_cash numeric, out_cash_difference numeric)
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_total_paid NUMERIC := 0;
BEGIN
  -- 1) تأكد أن الشفت مفتوح وللكاشير الصحيح
  IF NOT EXISTS (
    SELECT 1
    FROM shifts s
    WHERE s.id = p_shift_id
      AND s.cashier_id = p_cashier_id
      AND s.closed_at IS NULL
  ) THEN
    RAISE EXCEPTION 'Shift غير موجود/غير مفتوح أو ليس لهذا الكاشير';
  END IF;

  -- 2) منع الإغلاق إذا توجد فواتير pending داخل نفس الشفت
  IF EXISTS (
    SELECT 1
    FROM orders o
    WHERE o.shift_id = p_shift_id
      AND o.status = 'pending'
  ) THEN
    RAISE EXCEPTION 'لا يمكن إغلاق الشفت: توجد فواتير pending';
  END IF;

  -- 3) إجمالي المدفوع (paid) للشفت (لاحظ: o.total)
  SELECT COALESCE(SUM(o.total), 0)
  INTO v_total_paid
  FROM orders o
  WHERE o.shift_id = p_shift_id
    AND o.status = 'paid';

  -- 4) تحديث الشفت وإغلاقه
  UPDATE shifts s
  SET
    total_sales  = v_total_paid,
    counted_cash = p_counted_cash,
    closing_cash = p_counted_cash,
    status       = 'closed',
    closed_at    = NOW(),
    ended_at     = NOW()
  WHERE s.id = p_shift_id;

  RETURN QUERY
  SELECT
    p_shift_id,
    v_total_paid,
    p_counted_cash,
    (p_counted_cash - v_total_paid);
END;
$$;


--
-- Name: close_shift_cash(integer, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.close_shift_cash(p_shift_id integer, p_closing_cash numeric) RETURNS TABLE(shift_id integer, status text, opening_cash numeric, total_sales numeric, expected_cash numeric, actual_cash numeric, variance numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM shifts s
    WHERE s.id = p_shift_id AND s.status = 'open'
  ) THEN
    RAISE EXCEPTION 'Shift % is not open or does not exist', p_shift_id;
  END IF;

  IF EXISTS (
    SELECT 1 FROM orders o
    WHERE o.shift_id = p_shift_id
      AND o.status = 'pending'
  ) THEN
    RAISE EXCEPTION 'Cannot close shift %. There are pending orders.', p_shift_id;
  END IF;

  -- ✅ منع الإغلاق إذا لا توجد أي حركة
  IF NOT EXISTS (
    SELECT 1 FROM cash_movements cm
    WHERE cm.shift_id = p_shift_id
  ) THEN
    RAISE EXCEPTION 'Cannot close shift %. No cash movements recorded.', p_shift_id;
  END IF;

  RETURN QUERY
  WITH ledger AS (
    SELECT
      cm.shift_id,
      COALESCE(SUM(CASE WHEN cm.type='sale' THEN cm.amount ELSE 0 END), 0) AS sales_total,
      COALESCE(SUM(CASE WHEN cm.type='expense' THEN cm.amount ELSE 0 END), 0) AS expenses_total
    FROM cash_movements cm
    WHERE cm.shift_id = p_shift_id
    GROUP BY cm.shift_id
  ),
  calc AS (
    SELECT
      s.id AS shift_id,
      s.opening_cash,
      COALESCE(l.sales_total, 0) AS sales_total,
      COALESCE(l.expenses_total, 0) AS expenses_total,
      (s.opening_cash + COALESCE(l.sales_total,0) - COALESCE(l.expenses_total,0)) AS expected_cash
    FROM shifts s
    LEFT JOIN ledger l ON l.shift_id = s.id
    WHERE s.id = p_shift_id
  ),
  upd AS (
    UPDATE shifts s
    SET
      total_sales  = c.sales_total,
      total_cash   = c.expected_cash,
      total_bank   = 0,
      closing_cash = p_closing_cash,
      status       = 'closed',
      closed_at    = NOW(),
      ended_at     = NOW()
    FROM calc c
    WHERE s.id = c.shift_id
      AND s.status = 'open'
    RETURNING s.id, s.status, s.opening_cash, s.total_sales, s.total_cash, s.closing_cash
  )
  SELECT
    u.id AS shift_id,
    u.status,
    u.opening_cash,
    u.total_sales,
    u.total_cash AS expected_cash,
    u.closing_cash AS actual_cash,
    (u.closing_cash - u.total_cash) AS variance
  FROM upd u;
END;
$$;


--
-- Name: gen_order_number(integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.gen_order_number(p_branch_id integer, p_terminal_name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_no int;
BEGIN
  INSERT INTO public.order_counters(branch_id, terminal_name, last_no)
  VALUES (p_branch_id, p_terminal_name, 1)
  ON CONFLICT (branch_id, terminal_name)
  DO UPDATE SET last_no = public.order_counters.last_no + 1
  RETURNING last_no INTO v_no;

  RETURN
    'BR' || p_branch_id::text || '-' || p_terminal_name || '-ORD-' || lpad(v_no::text, 6, '0');
END;
$$;


--
-- Name: generate_invoice_number(integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.generate_invoice_number(p_branch_id integer, p_terminal_code text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_next int;
BEGIN
  INSERT INTO public.invoice_counters(branch_id, terminal_code, last_number)
  VALUES (p_branch_id, p_terminal_code, 0)
  ON CONFLICT (branch_id, terminal_code) DO NOTHING;

  UPDATE public.invoice_counters
  SET last_number = last_number + 1
  WHERE branch_id = p_branch_id
    AND terminal_code = p_terminal_code
  RETURNING last_number INTO v_next;

  RETURN
    'BR' || p_branch_id::text ||
    '-T' || p_terminal_code ||
    '-INV-' || LPAD(v_next::text, 6, '0');
END;
$$;


--
-- Name: get_open_shift_for_terminal(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_open_shift_for_terminal(p_terminal_name text) RETURNS TABLE(out_shift_id integer, out_branch_id integer, out_cashier_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY
  SELECT s.id, s.branch_id, s.cashier_id
  FROM public.shifts s
  WHERE s.terminal_name = p_terminal_name
    AND s.closed_at IS NULL
    AND LOWER(COALESCE(s.status,'')) IN ('open','opened','active')
  ORDER BY s.id DESC
  LIMIT 1;
END;
$$;


--
-- Name: next_order_number(integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.next_order_number(p_branch_id integer, p_terminal_name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_next   int;
  v_prefix text;
BEGIN
  INSERT INTO public.order_counters(branch_id, terminal_name, last_no)
  VALUES (p_branch_id, p_terminal_name, 1)
  ON CONFLICT (branch_id, terminal_name)
  DO UPDATE SET last_no = public.order_counters.last_no + 1
  RETURNING last_no INTO v_next;

  v_prefix := format('BR%s-%s-ORD-', p_branch_id, p_terminal_name);
  RETURN v_prefix || lpad(v_next::text, 6, '0');
END;
$$;


--
-- Name: pay_order(integer, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pay_order(p_order_id integer, p_payment_method text, p_bank_txn_id text DEFAULT NULL::text, p_bank_receipt_image text DEFAULT NULL::text) RETURNS TABLE(order_id integer, new_status text, payment_method text, paid_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- 1) لازم يكون الطلب موجود
  IF NOT EXISTS (SELECT 1 FROM orders WHERE id = p_order_id) THEN
    RAISE EXCEPTION 'Order غير موجود';
  END IF;

  -- 2) منع الدفع إذا ملغي أو مدفوع
  IF EXISTS (
    SELECT 1 FROM orders
    WHERE id = p_order_id AND status IN ('paid','cancelled')
  ) THEN
    RAISE EXCEPTION 'لا يمكن الدفع: الطلب مدفوع أو ملغي';
  END IF;

  -- 3) إذا تحويل/بطاقة، نحتاج رقم عملية (اختياري حسب رغبتك)
  IF p_payment_method IN ('card','bank_transfer') AND (p_bank_txn_id IS NULL OR length(trim(p_bank_txn_id)) = 0) THEN
    RAISE EXCEPTION 'رقم العملية البنكية مطلوب لهذه الطريقة';
  END IF;

  UPDATE orders
  SET
    status = 'paid',
    payment_method = p_payment_method,
    bank_txn_id = p_bank_txn_id,
    bank_receipt_image = p_bank_receipt_image,
    paid_at = NOW()
  WHERE id = p_order_id;

  RETURN QUERY
  SELECT o.id, o.status, o.payment_method, o.paid_at
  FROM orders o
  WHERE o.id = p_order_id;
END;
$$;


--
-- Name: pay_order(integer, text, text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pay_order(p_order_id integer, p_terminal_name text, p_pin text, p_payment_method text, p_bank_txn_id text, p_bank_receipt_image text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN

    -- مثال تحديث الطلب
    UPDATE orders
    SET status = 'paid'
    WHERE id = p_order_id;

END;
$$;


--
-- Name: pos_close_shift_by_pin(text, text, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pos_close_shift_by_pin(p_terminal_code text, p_pin text, p_closing_cash numeric) RETURNS TABLE(out_shift_id integer, out_branch_id integer, out_cashier_id integer, out_total_sales numeric, out_expected_cash numeric, out_difference numeric, out_status text, out_message text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_shift_id int;
    v_branch_id int;
    v_cashier_id int;
    v_opening_cash numeric(12,3);
    v_opened_at timestamptz;

    v_total_sales numeric(12,3) := 0;
    v_cash_sales  numeric(12,3) := 0;
    v_expected_cash numeric(12,3) := 0;
    v_diff numeric(12,3) := 0;

    v_pending_count int := 0;
BEGIN
    -- 1) تحقق PIN
    SELECT u.id
    INTO v_cashier_id
    FROM public.users u
    WHERE u.pin_code = p_pin;

    IF v_cashier_id IS NULL THEN
        RETURN QUERY
        SELECT 0,0,0,0::numeric,0::numeric,0::numeric,'error','Invalid PIN';
        RETURN;
    END IF;

    -- 2) جلب الشفت "المفتوح" (مرن: status أو closed_at)
    SELECT s.id, s.branch_id, s.cashier_id, COALESCE(s.opening_cash,0), s.opened_at
    INTO v_shift_id, v_branch_id, v_cashier_id, v_opening_cash, v_opened_at
    FROM public.shifts s
    WHERE s.terminal_name = p_terminal_code
      AND (LOWER(COALESCE(s.status,'')) IN ('open','opened','active') OR s.closed_at IS NULL)
    ORDER BY s.id DESC
    LIMIT 1;

    IF v_shift_id IS NULL THEN
        RETURN QUERY
        SELECT 0,0,0,0::numeric,0::numeric,0::numeric,'error','No open shift for this terminal';
        RETURN;
    END IF;

    -- 3) منع الإغلاق إذا توجد Orders معلّقة (حسب الفرع)
    SELECT COUNT(*)
    INTO v_pending_count
    FROM public.orders o
    WHERE o.branch_id = v_branch_id
      AND LOWER(COALESCE(o.status,'')) IN ('pending','open','draft','hold');

    IF v_pending_count > 0 THEN
        RETURN QUERY
        SELECT v_shift_id, v_branch_id, v_cashier_id,
               0::numeric, 0::numeric, 0::numeric,
               'error', 'Cannot close: pending orders exist';
        RETURN;
    END IF;

    -- 4) إجمالي المبيعات للشفت + مبيعات الكاش فقط
    SELECT
        COALESCE(SUM(COALESCE(sa.total,0)),0),
        COALESCE(SUM(
            CASE
              WHEN LOWER(COALESCE(sa.payment_method,'')) IN ('cash','كاش')
              THEN COALESCE(sa.total,0)
              ELSE 0
            END
        ),0)
    INTO v_total_sales, v_cash_sales
    FROM public.sales sa
    WHERE sa.shift_id = v_shift_id;

    v_expected_cash := v_opening_cash + v_cash_sales;
    v_diff := p_closing_cash - v_expected_cash;

    -- 5) تحديث الشفت
    UPDATE public.shifts sh
    SET status = 'closed',
        closed_at = now(),
        closing_cash = p_closing_cash,
        total_sales = v_total_sales,
        expected_cash = v_expected_cash,
        cash_difference = v_diff
    WHERE sh.id = v_shift_id;

    RETURN QUERY
    SELECT v_shift_id, v_branch_id, v_cashier_id,
           v_total_sales, v_expected_cash, v_diff,
           'success', 'Shift closed successfully';
END;
$$;


--
-- Name: pos_close_shift_by_pin_v2(text, text, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pos_close_shift_by_pin_v2(p_terminal_name text, p_pin text, p_closing_cash numeric) RETURNS TABLE(out_shift_id integer, out_branch_id integer, out_cashier_id integer, out_total_sales numeric, out_expected_cash numeric, out_difference numeric, out_status text, out_message text)
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_user_id int;
  v_shift_id int;
  v_branch_id int;
  v_cashier_id int;
  v_total_sales numeric(12,3);
  v_cash_sales  numeric(12,3);
BEGIN
  -- PIN
  SELECT u.id INTO v_user_id
  FROM public.users u
  WHERE u.pin_code = p_pin
  LIMIT 1;

  IF v_user_id IS NULL THEN
    RETURN QUERY
    SELECT
      0::int, 0::int, 0::int,
      0::numeric(12,3), 0::numeric(12,3), 0::numeric(12,3),
      'error'::text, 'Invalid PIN'::text;
    RETURN;
  END IF;

  -- open shift (حل نهائي للـ ambiguous)
  SELECT g.out_shift_id, g.out_branch_id, g.out_cashier_id
    INTO v_shift_id, v_branch_id, v_cashier_id
  FROM public.get_open_shift_for_terminal(p_terminal_name) AS g;

  IF v_shift_id IS NULL THEN
    RETURN QUERY
    SELECT
      0::int, 0::int, 0::int,
      0::numeric(12,3), 0::numeric(12,3), 0::numeric(12,3),
      'error'::text, 'No open shift for this terminal'::text;
    RETURN;
  END IF;

  -- منع الإغلاق إذا فيه pending
  IF EXISTS (
    SELECT 1
    FROM public.orders o
    WHERE o.shift_id = v_shift_id
      AND o.status = 'pending'
  ) THEN
    RETURN QUERY
    SELECT
      v_shift_id::int, v_branch_id::int, v_cashier_id::int,
      0::numeric(12,3), 0::numeric(12,3), 0::numeric(12,3),
      'error'::text, 'Cannot close shift: there are pending orders'::text;
    RETURN;
  END IF;

  -- إجماليات المبيعات
  SELECT
    COALESCE(SUM(s.total),0)::numeric(12,3),
    COALESCE(SUM(CASE WHEN LOWER(COALESCE(s.payment_method,'')) IN ('cash','كاش')
                      THEN s.total ELSE 0 END),0)::numeric(12,3)
  INTO v_total_sales, v_cash_sales
  FROM public.sales s
  WHERE s.shift_id = v_shift_id;

  -- إغلاق الشفت
  UPDATE public.shifts
  SET closed_at = now(),
      status = 'closed',
      closing_cash = p_closing_cash,
      total_sales = v_total_sales,
      expected_cash = v_cash_sales,
      cash_difference = (COALESCE(p_closing_cash,0)::numeric(12,3) - v_cash_sales)
  WHERE id = v_shift_id;

  RETURN QUERY
  SELECT
    v_shift_id::int, v_branch_id::int, v_cashier_id::int,
    v_total_sales::numeric(12,3),
    v_cash_sales::numeric(12,3),
    (COALESCE(p_closing_cash,0)::numeric(12,3) - v_cash_sales)::numeric(12,3),
    'success'::text, 'Shift closed successfully'::text;
END;
$$;


--
-- Name: pos_create_order_by_pin(text, text, text, text, text, text, text, text, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pos_create_order_by_pin(p_terminal_name text, p_pin text, p_customer_name text DEFAULT NULL::text, p_customer_phone text DEFAULT NULL::text, p_city text DEFAULT NULL::text, p_address text DEFAULT NULL::text, p_delivery_type text DEFAULT NULL::text, p_notes text DEFAULT NULL::text, p_total numeric DEFAULT 0) RETURNS TABLE(out_order_id integer, out_shift_id integer, out_branch_id integer, out_cashier_id integer, out_status text, out_message text)
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_user_id int;
  v_shift_id int;
  v_branch_id int;
  v_cashier_id int;
BEGIN
  SELECT u.id INTO v_user_id
  FROM public.users u
  WHERE u.pin_code = p_pin
  LIMIT 1;

  IF v_user_id IS NULL THEN
    RETURN QUERY SELECT 0, 0, 0, 0, 'error', 'Invalid PIN';
    RETURN;
  END IF;

  SELECT g.out_shift_id, g.out_branch_id, g.out_cashier_id
    INTO v_shift_id, v_branch_id, v_cashier_id
  FROM public.get_open_shift_for_terminal(p_terminal_name) AS g;

  IF v_shift_id IS NULL THEN
    RETURN QUERY SELECT 0, 0, 0, 0, 'error', 'No open shift for this terminal';
    RETURN;
  END IF;

  INSERT INTO public.orders(
    customer_name, customer_phone, city, address,
    branch_id, delivery_type, status, total, notes,
    shift_id, cashier_id
  )
  VALUES (
    p_customer_name, p_customer_phone, p_city, p_address,
    v_branch_id, p_delivery_type, 'pending', COALESCE(p_total,0), p_notes,
    v_shift_id, v_user_id
  )
  RETURNING id INTO out_order_id;

  RETURN QUERY SELECT out_order_id, v_shift_id, v_branch_id, v_user_id, 'success', 'Order created';
END;
$$;


--
-- Name: pos_get_open_shift_by_pin(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pos_get_open_shift_by_pin(p_terminal_code text, p_pin text) RETURNS TABLE(out_shift_id integer, out_branch_id integer, out_cashier_id integer, out_status text, out_message text)
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_user_id int;
BEGIN
  SELECT u.id INTO v_user_id
  FROM public.users u
  WHERE u.pin_code = p_pin;

  IF v_user_id IS NULL THEN
    RETURN QUERY SELECT 0,0,0,'error','Invalid PIN';
    RETURN;
  END IF;

  SELECT s.id, s.branch_id, s.cashier_id, 'success'::text, 'Open shift found'::text
  INTO out_shift_id, out_branch_id, out_cashier_id, out_status, out_message
  FROM public.shifts s
  WHERE s.terminal_name = p_terminal_code
    AND LOWER(COALESCE(s.status,'')) = 'open'
    AND s.closed_at IS NULL
  ORDER BY s.id DESC
  LIMIT 1;

  IF out_shift_id IS NULL THEN
    RETURN QUERY SELECT 0,0,0,'error','No open shift for this terminal';
    RETURN;
  END IF;

  RETURN NEXT;
END;
$$;


--
-- Name: pos_open_shift_by_pin(text, text, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pos_open_shift_by_pin(p_terminal_code text, p_pin text, p_opening_cash numeric DEFAULT 0) RETURNS TABLE(out_shift_id integer, out_branch_id integer, out_cashier_id integer, out_status text, out_message text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_branch_id int;
    v_cashier_id int;
    v_existing_shift_id int;
BEGIN
    -- 1) تحقق من وجود التيرمنال + جلب الفرع
    SELECT pt.branch_id
    INTO v_branch_id
    FROM public.pos_terminals pt
    WHERE pt.terminal_code = p_terminal_code;

    IF v_branch_id IS NULL THEN
        RETURN QUERY SELECT 0,0,0,'error','Terminal not found';
        RETURN;
    END IF;

    -- 2) تحقق من الـ PIN (حسب جدول users وعمود pin_code)
    SELECT u.id
    INTO v_cashier_id
    FROM public.users u
    WHERE u.pin_code = p_pin;

    IF v_cashier_id IS NULL THEN
        RETURN QUERY SELECT 0,0,0,'error','Invalid PIN';
        RETURN;
    END IF;

    -- 3) منع فتح شفت إذا فيه شفت مفتوح لنفس الجهاز
    SELECT s.id
    INTO v_existing_shift_id
    FROM public.shifts s
    WHERE s.terminal_name = p_terminal_code
      AND COALESCE(s.status,'') = 'open'
    ORDER BY s.id DESC
    LIMIT 1;

    IF v_existing_shift_id IS NOT NULL THEN
        RETURN QUERY SELECT v_existing_shift_id, v_branch_id, v_cashier_id, 'error', 'Shift already open';
        RETURN;
    END IF;

    -- 4) إنشاء الشفت
    INSERT INTO public.shifts (
        branch_id,
        cashier_id,
        terminal_name,
        opening_cash,
        opened_at,
        status
    )
    VALUES (
        v_branch_id,
        v_cashier_id,
        p_terminal_code,
        p_opening_cash,
        now(),
        'open'
    )
    RETURNING id INTO v_existing_shift_id;

    RETURN QUERY
    SELECT v_existing_shift_id, v_branch_id, v_cashier_id, 'success', 'Shift opened successfully';
END;
$$;


--
-- Name: pos_pay_order_by_pin(integer, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pos_pay_order_by_pin(p_order_id integer, p_terminal_name text, p_pin text, p_payment_method text) RETURNS TABLE(out_sale_id integer, out_invoice_number text, out_shift_id integer, out_status text, out_message text)
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_user_id int;
  v_shift_id int;
  v_branch_id int;
  v_cashier_id int;

  v_total numeric;
  v_order_status text;

  v_invoice_number text;
  v_sale_id int;
BEGIN
  -- 1) تحقق PIN
  SELECT u.id INTO v_user_id
  FROM public.users u
  WHERE u.pin_code = p_pin
  LIMIT 1;

  IF v_user_id IS NULL THEN
    RETURN QUERY SELECT 0, NULL::text, 0, 'error', 'Invalid PIN';
    RETURN;
  END IF;

  -- 2) جلب الشفت المفتوح للجهاز
  SELECT g.out_shift_id, g.out_branch_id, g.out_cashier_id
    INTO v_shift_id, v_branch_id, v_cashier_id
  FROM public.get_open_shift_for_terminal(p_terminal_name) AS g;

  IF v_shift_id IS NULL THEN
    RETURN QUERY SELECT 0, NULL::text, 0, 'error', 'No open shift for this terminal';
    RETURN;
  END IF;

  -- 3) تأكد الطلب موجود على نفس الشفت + pending
  SELECT o.total, o.status
    INTO v_total, v_order_status
  FROM public.orders o
  WHERE o.id = p_order_id
    AND o.shift_id = v_shift_id;

  IF NOT FOUND THEN
    RETURN QUERY SELECT 0, NULL::text, v_shift_id, 'error', 'Order not found for this shift';
    RETURN;
  END IF;

  IF COALESCE(LOWER(v_order_status),'') <> 'pending' THEN
    RETURN QUERY SELECT 0, NULL::text, v_shift_id, 'error', 'Order is not pending';
    RETURN;
  END IF;

  -- 4) توليد رقم فاتورة للمبيعات
  v_invoice_number := 'INV-' || to_char(now(), 'YYYYMMDD') || '-' || lpad(nextval('public.sales_invoice_seq')::text, 6, '0');

  -- 5) إدخال سجل في sales (مطابق لأعمدتك)
  INSERT INTO public.sales(
    invoice_number,
    branch_id,
    cashier_id,
    subtotal,
    discount,
    discount_type,
    vat,
    tax,
    total,
    payment_method,
    bank_txn_id,
    bank_receipt_image,
    shift_id
  )
  VALUES (
    v_invoice_number,
    v_branch_id,
    v_user_id,
    COALESCE(v_total,0),
    0,
    NULL,
    0,
    0,
    COALESCE(v_total,0),
    COALESCE(p_payment_method,'cash'),
    NULL,
    NULL,
    v_shift_id
  )
  RETURNING id INTO v_sale_id;

  -- 6) تحديث حالة الطلب إلى paid
  UPDATE public.orders
  SET status = 'paid'
  WHERE id = p_order_id;

  RETURN QUERY SELECT v_sale_id, v_invoice_number, v_shift_id, 'success', 'Payment completed';
END;
$$;


--
-- Name: pos_pay_order_by_pin(integer, text, text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.pos_pay_order_by_pin(p_order_id integer, p_terminal_name text, p_pin text, p_payment_method text DEFAULT 'cash'::text, p_bank_txn_id text DEFAULT NULL::text, p_bank_receipt_image text DEFAULT NULL::text) RETURNS TABLE(out_sale_id integer, out_invoice_number text, out_shift_id integer, out_status text, out_message text)
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_user_id int;
  v_shift_id int;
  v_branch_id int;
  v_open_shift_id int;
  v_order_branch_id int;
  v_order_shift_id int;
  v_order_status text;
  v_order_total numeric;
  v_sale_id int;
  v_invoice text;
BEGIN
  SELECT u.id INTO v_user_id
  FROM public.users u
  WHERE u.pin_code = p_pin
  LIMIT 1;

  IF v_user_id IS NULL THEN
    RETURN QUERY SELECT 0, NULL, 0, 'error', 'Invalid PIN';
    RETURN;
  END IF;

  -- lock the order
  SELECT o.branch_id, o.shift_id, o.status, o.total
    INTO v_order_branch_id, v_order_shift_id, v_order_status, v_order_total
  FROM public.orders o
  WHERE o.id = p_order_id
  FOR UPDATE;

  IF v_order_shift_id IS NULL THEN
    RETURN QUERY SELECT 0, NULL, 0, 'error', 'Order has no shift_id';
    RETURN;
  END IF;

  IF LOWER(COALESCE(v_order_status,'')) IN ('paid','completed','done','closed','cancelled','canceled') THEN
    RETURN QUERY SELECT 0, NULL, v_order_shift_id, 'error', 'Order already finalized';
    RETURN;
  END IF;

  -- must be same current open shift for that terminal
  SELECT out_shift_id, out_branch_id
    INTO v_open_shift_id, v_branch_id
  FROM public.get_open_shift_for_terminal(p_terminal_name);

  IF v_open_shift_id IS NULL THEN
    RETURN QUERY SELECT 0, NULL, v_order_shift_id, 'error', 'No open shift for this terminal';
    RETURN;
  END IF;

  IF v_open_shift_id <> v_order_shift_id THEN
    RETURN QUERY SELECT 0, NULL, v_open_shift_id, 'error', 'Order belongs to different shift';
    RETURN;
  END IF;

  -- Create sale (invoice_number generated by your existing trigger)
  INSERT INTO public.sales(
    branch_id, cashier_id, shift_id,
    subtotal, vat, total,
    payment_method, bank_txn_id, bank_receipt_image,
    created_at
  )
  VALUES (
    v_order_branch_id, v_user_id, v_open_shift_id,
    COALESCE(v_order_total,0), 0, COALESCE(v_order_total,0),
    p_payment_method, p_bank_txn_id, p_bank_receipt_image,
    now()
  )
  RETURNING id, invoice_number INTO v_sale_id, v_invoice;

  -- mark order as paid
  UPDATE public.orders
  SET status='paid',
      paid_sale_id=v_sale_id,
      paid_at=now()
  WHERE id=p_order_id;

  RETURN QUERY SELECT v_sale_id, v_invoice, v_open_shift_id, 'success', 'Order paid and sale created';
END;
$$;


--
-- Name: sale_items_apply_inventory_and_update_sale(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sale_items_apply_inventory_and_update_sale() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_branch_id    INTEGER;
  v_warehouse_id INTEGER;
  v_available    INTEGER;
  v_subtotal     NUMERIC(12,3);
  v_discount     NUMERIC(12,3);
  v_vat          NUMERIC(12,3);
BEGIN
  -- نحدد sale_id حسب العملية
  IF TG_OP = 'DELETE' THEN
    SELECT branch_id INTO v_branch_id FROM sales WHERE id = OLD.sale_id;
  ELSE
    SELECT branch_id INTO v_branch_id FROM sales WHERE id = NEW.sale_id;
  END IF;

  IF v_branch_id IS NULL THEN
    RAISE EXCEPTION 'Sale not found or missing branch_id';
  END IF;

  -- نحدد المخزن الرئيسي للفرع
  SELECT id INTO v_warehouse_id
  FROM warehouses
  WHERE branch_id = v_branch_id AND is_main = TRUE
  ORDER BY id
  LIMIT 1;

  IF v_warehouse_id IS NULL THEN
    RAISE EXCEPTION 'No main warehouse found for branch_id %', v_branch_id;
  END IF;

  -- التعامل حسب نوع العملية
  IF TG_OP = 'INSERT' THEN
    -- تحقق المخزون
    SELECT quantity INTO v_available
    FROM inventory
    WHERE product_id = NEW.product_id AND warehouse_id = v_warehouse_id;

    IF v_available IS NULL THEN
      RAISE EXCEPTION 'No inventory row for product_id % in warehouse_id %', NEW.product_id, v_warehouse_id;
    END IF;

    IF v_available < NEW.quantity THEN
      RAISE EXCEPTION 'Insufficient stock: available %, requested %', v_available, NEW.quantity;
    END IF;

    -- خصم المخزون
    UPDATE inventory
    SET quantity = quantity - NEW.quantity
    WHERE product_id = NEW.product_id AND warehouse_id = v_warehouse_id;

  ELSIF TG_OP = 'DELETE' THEN
    -- إرجاع المخزون
    UPDATE inventory
    SET quantity = quantity + OLD.quantity
    WHERE product_id = OLD.product_id AND warehouse_id = v_warehouse_id;

  ELSIF TG_OP = 'UPDATE' THEN
    -- أولاً: رجّع القديم
    UPDATE inventory
    SET quantity = quantity + OLD.quantity
    WHERE product_id = OLD.product_id AND warehouse_id = v_warehouse_id;

    -- ثم: تحقق وخصم الجديد
    SELECT quantity INTO v_available
    FROM inventory
    WHERE product_id = NEW.product_id AND warehouse_id = v_warehouse_id;

    IF v_available IS NULL THEN
      RAISE EXCEPTION 'No inventory row for product_id % in warehouse_id %', NEW.product_id, v_warehouse_id;
    END IF;

    IF v_available < NEW.quantity THEN
      -- رجّع القديم كان تم، فلازم نمنع التحديث
      RAISE EXCEPTION 'Insufficient stock after update: available %, requested %', v_available, NEW.quantity;
    END IF;

    UPDATE inventory
    SET quantity = quantity - NEW.quantity
    WHERE product_id = NEW.product_id AND warehouse_id = v_warehouse_id;
  END IF;

  -- تحديث إجماليات الفاتورة في sales
  IF TG_OP = 'DELETE' THEN
    SELECT COALESCE(SUM(total),0) INTO v_subtotal
    FROM sale_items
    WHERE sale_id = OLD.sale_id;

    SELECT COALESCE(discount,0), COALESCE(vat,0)
      INTO v_discount, v_vat
    FROM sales
    WHERE id = OLD.sale_id;

    UPDATE sales
    SET subtotal = v_subtotal,
        total    = (v_subtotal - v_discount + v_vat)
    WHERE id = OLD.sale_id;

  ELSE
    SELECT COALESCE(SUM(total),0) INTO v_subtotal
    FROM sale_items
    WHERE sale_id = NEW.sale_id;

    SELECT COALESCE(discount,0), COALESCE(vat,0)
      INTO v_discount, v_vat
    FROM sales
    WHERE id = NEW.sale_id;

    UPDATE sales
    SET subtotal = v_subtotal,
        total    = (v_subtotal - v_discount + v_vat)
    WHERE id = NEW.sale_id;
  END IF;

  RETURN NULL;
END;
$$;


--
-- Name: sale_items_set_total(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sale_items_set_total() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.total := COALESCE(NEW.quantity, 0) * COALESCE(NEW.unit_price, 0);
  RETURN NEW;
END;
$$;


--
-- Name: trg_orders_set_order_number(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_orders_set_order_number() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_terminal text;
  v_branch int;
BEGIN
  IF NEW.order_number IS NOT NULL AND btrim(NEW.order_number) <> '' THEN
    RETURN NEW;
  END IF;

  -- جِب terminal_name والفرع من الشفت
  IF NEW.shift_id IS NOT NULL THEN
    SELECT s.terminal_name, s.branch_id
    INTO v_terminal, v_branch
    FROM public.shifts s
    WHERE s.id = NEW.shift_id;
  END IF;

  -- ثبت branch_id إن لم يكن موجود
  IF NEW.branch_id IS NULL THEN
    NEW.branch_id := v_branch;
  END IF;

  IF NEW.branch_id IS NULL THEN
    RAISE EXCEPTION 'Cannot set order_number: branch_id is NULL';
  END IF;

  IF v_terminal IS NULL OR btrim(v_terminal) = '' THEN
    v_terminal := 'POS';
  END IF;

  NEW.order_number := public.gen_order_number(NEW.branch_id, v_terminal);
  RETURN NEW;
END;
$$;


--
-- Name: trg_sales_set_invoice_number(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_sales_set_invoice_number() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_terminal_code text;
BEGIN
  IF NEW.invoice_number IS NOT NULL AND NEW.invoice_number <> '' THEN
    RETURN NEW;
  END IF;

  IF NEW.shift_id IS NULL THEN
    RAISE EXCEPTION 'shift_id is required to generate invoice_number';
  END IF;

  SELECT s.terminal_name INTO v_terminal_code
  FROM public.shifts s
  WHERE s.id = NEW.shift_id;

  IF v_terminal_code IS NULL OR v_terminal_code = '' THEN
    v_terminal_code := 'UNKNOWN';
  END IF;

  IF NEW.branch_id IS NULL THEN
    RAISE EXCEPTION 'branch_id is required to generate invoice_number';
  END IF;

  NEW.invoice_number := public.generate_invoice_number(NEW.branch_id, v_terminal_code);
  RETURN NEW;
END;
$$;


--
-- Name: trg_validate_expense_shift(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_validate_expense_shift() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM shifts s
    WHERE s.id = NEW.shift_id
      AND s.status = 'open'
  ) THEN
    RAISE EXCEPTION 'Cannot create expense. Shift % is not open.', NEW.shift_id;
  END IF;

  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id integer,
    branch_id integer,
    user_id integer,
    user_name text,
    details text,
    old_value text,
    new_value text,
    ip_address text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bank_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_ledger (
    id integer NOT NULL,
    date date NOT NULL,
    branch_id integer NOT NULL,
    shift_id integer,
    method text NOT NULL,
    amount_in numeric(12,3) DEFAULT 0,
    amount_out numeric(12,3) DEFAULT 0,
    ref_id text,
    note text,
    created_by integer,
    created_at timestamp without time zone DEFAULT now(),
    category text
);


--
-- Name: bank_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.bank_ledger ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.bank_ledger_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branches (
    id integer NOT NULL,
    name text NOT NULL,
    address text,
    is_main boolean DEFAULT false
);


--
-- Name: branches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.branches ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.branches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cash_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_ledger (
    id integer NOT NULL,
    date date NOT NULL,
    branch_id integer NOT NULL,
    shift_id integer,
    type text NOT NULL,
    amount_in numeric(12,3) DEFAULT 0,
    amount_out numeric(12,3) DEFAULT 0,
    note text,
    created_by integer,
    created_at timestamp without time zone DEFAULT now(),
    category text
);


--
-- Name: cash_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cash_ledger ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.cash_ledger_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name text NOT NULL
);


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.categories ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cities (
    id integer NOT NULL,
    name text NOT NULL,
    branch_id integer
);


--
-- Name: cities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cities ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.cities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name text,
    phone text,
    city text,
    address text,
    total_spent numeric(12,3) DEFAULT '0'::numeric,
    visits integer DEFAULT 0,
    last_visit timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.customers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.customers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: employee_advances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_advances (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    amount numeric(10,3) NOT NULL,
    date date NOT NULL,
    note text,
    settled boolean DEFAULT false NOT NULL,
    settled_in_payroll_id integer,
    created_by integer,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: employee_advances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.employee_advances ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.employee_advances_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: employee_deductions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_deductions (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    amount numeric(10,3) NOT NULL,
    reason text NOT NULL,
    date date NOT NULL,
    applied_in_payroll_id integer,
    created_by integer,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: employee_deductions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.employee_deductions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.employee_deductions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    name text NOT NULL,
    phone text,
    branch_id integer,
    salary numeric(10,3) NOT NULL,
    role text
);


--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.employees ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.employees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    branch_id integer NOT NULL,
    category text NOT NULL,
    amount numeric(10,3) NOT NULL,
    date date NOT NULL,
    notes text,
    receipt_image text,
    created_at timestamp without time zone DEFAULT now(),
    shift_id integer,
    source text DEFAULT 'cash'::text NOT NULL,
    created_by integer
);


--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.expenses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.expenses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory (
    id integer NOT NULL,
    product_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    min_quantity integer DEFAULT 5
);


--
-- Name: inventory_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_adjustments (
    id integer NOT NULL,
    branch_id integer NOT NULL,
    location_id integer NOT NULL,
    product_id integer NOT NULL,
    type text NOT NULL,
    qty_before integer NOT NULL,
    qty_change integer NOT NULL,
    qty_after integer NOT NULL,
    reason text NOT NULL,
    stocktake_id integer,
    created_by integer,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: inventory_adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.inventory_adjustments ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.inventory_adjustments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: inventory_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_balances (
    id integer NOT NULL,
    location_id integer NOT NULL,
    variant_id integer NOT NULL,
    qty_on_hand integer DEFAULT 0 NOT NULL,
    qty_reserved integer DEFAULT 0 NOT NULL
);


--
-- Name: inventory_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.inventory_balances ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.inventory_balances_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.inventory ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.inventory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: inventory_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_ledger (
    id integer NOT NULL,
    variant_id integer NOT NULL,
    location_id integer NOT NULL,
    qty_change integer NOT NULL,
    reason text NOT NULL,
    ref_table text,
    ref_id integer,
    created_by integer,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: inventory_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.inventory_ledger ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.inventory_ledger_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: inventory_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_transactions (
    id integer NOT NULL,
    date date NOT NULL,
    branch_id integer,
    from_location_id integer,
    to_location_id integer,
    product_id integer NOT NULL,
    type text NOT NULL,
    qty integer DEFAULT 0 NOT NULL,
    ref_table text,
    ref_id integer,
    note text,
    created_by integer,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: inventory_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.inventory_transactions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.inventory_transactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: inventory_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_transfers (
    id integer NOT NULL,
    product_id integer NOT NULL,
    from_warehouse_id integer NOT NULL,
    to_warehouse_id integer NOT NULL,
    quantity integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    created_by integer
);


--
-- Name: inventory_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.inventory_transfers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.inventory_transfers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: location_inventory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_inventory (
    id integer NOT NULL,
    location_id integer NOT NULL,
    product_id integer NOT NULL,
    qty_on_hand integer DEFAULT 0 NOT NULL,
    reorder_level integer DEFAULT 5 NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: location_inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.location_inventory ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.location_inventory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: location_transfer_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_transfer_items (
    id integer NOT NULL,
    transfer_id integer NOT NULL,
    product_id integer NOT NULL,
    qty integer NOT NULL
);


--
-- Name: location_transfer_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.location_transfer_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.location_transfer_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: location_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_transfers (
    id integer NOT NULL,
    branch_id integer NOT NULL,
    from_location_id integer NOT NULL,
    to_location_id integer NOT NULL,
    note text,
    created_by integer,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: location_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.location_transfers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.location_transfers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.locations (
    id integer NOT NULL,
    branch_id integer,
    code text NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    type text DEFAULT 'MAIN_WAREHOUSE'::text NOT NULL,
    is_main boolean DEFAULT false NOT NULL,
    kind text DEFAULT 'BRANCH_STORE'::text,
    is_central boolean DEFAULT false NOT NULL,
    is_branch_default boolean DEFAULT false NOT NULL
);


--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.locations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.locations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(10,3) NOT NULL,
    total numeric(10,3) NOT NULL,
    unit_cost_at_sale numeric(10,3) DEFAULT 0,
    line_cogs numeric(10,3) DEFAULT 0
);


--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.order_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.order_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    order_number text NOT NULL,
    customer_name text NOT NULL,
    customer_phone text,
    city text,
    address text,
    branch_id integer,
    delivery_type text DEFAULT 'pickup'::text,
    status text DEFAULT 'new'::text,
    total numeric(10,3),
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    shift_id integer,
    payment_method text DEFAULT 'cash'::text,
    bank_txn_id text,
    paid_at timestamp without time zone,
    cogs_total numeric(10,3) DEFAULT '0'::numeric,
    gross_profit numeric(10,3) DEFAULT '0'::numeric,
    employee_id integer
);


--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.orders ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: payroll_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_details (
    id integer NOT NULL,
    payroll_id integer NOT NULL,
    employee_id integer NOT NULL,
    basic_salary numeric(10,3) NOT NULL,
    commission numeric(10,3) DEFAULT '0'::numeric,
    deductions numeric(10,3) DEFAULT '0'::numeric,
    advances numeric(10,3) DEFAULT '0'::numeric,
    bonus numeric(10,3) DEFAULT '0'::numeric,
    net_salary numeric(10,3) NOT NULL,
    note text
);


--
-- Name: payroll_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.payroll_details ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.payroll_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: payroll_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_runs (
    id integer NOT NULL,
    month text NOT NULL,
    year integer NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    total_basic numeric(12,3) DEFAULT '0'::numeric,
    total_commission numeric(12,3) DEFAULT '0'::numeric,
    total_deductions numeric(12,3) DEFAULT '0'::numeric,
    total_advances numeric(12,3) DEFAULT '0'::numeric,
    total_net numeric(12,3) DEFAULT '0'::numeric,
    note text,
    created_by integer,
    approved_by integer,
    created_at timestamp without time zone DEFAULT now(),
    approved_at timestamp without time zone
);


--
-- Name: payroll_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.payroll_runs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.payroll_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_variants (
    id integer NOT NULL,
    product_id integer NOT NULL,
    sku text,
    barcode text,
    color text,
    size text,
    cost_default numeric(10,3),
    price numeric(10,3) NOT NULL,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: product_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.product_variants ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.product_variants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    barcode text,
    name text NOT NULL,
    category_id integer,
    price numeric(10,3) NOT NULL,
    image text,
    active boolean DEFAULT true,
    branch_id integer,
    avg_cost numeric(10,3) DEFAULT '0'::numeric,
    stock_qty integer DEFAULT 0
);


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.products ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: purchase_extra_costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_extra_costs (
    id integer NOT NULL,
    purchase_invoice_id integer NOT NULL,
    type text NOT NULL,
    amount numeric(10,3) NOT NULL,
    notes text
);


--
-- Name: purchase_extra_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.purchase_extra_costs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.purchase_extra_costs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: purchase_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_invoices (
    id integer NOT NULL,
    invoice_number text NOT NULL,
    supplier_id integer NOT NULL,
    branch_id integer,
    invoice_date date NOT NULL,
    shipping_cost numeric(10,3) DEFAULT '0'::numeric,
    customs_cost numeric(10,3) DEFAULT '0'::numeric,
    clearance_cost numeric(10,3) DEFAULT '0'::numeric,
    other_cost numeric(10,3) DEFAULT '0'::numeric,
    subtotal numeric(10,3) DEFAULT '0'::numeric,
    total_extra_cost numeric(10,3) DEFAULT '0'::numeric,
    grand_total numeric(10,3) DEFAULT '0'::numeric,
    status text DEFAULT 'pending'::text NOT NULL,
    notes text,
    created_by integer,
    created_at timestamp without time zone DEFAULT now(),
    received_at timestamp without time zone,
    total_amount numeric(10,3) DEFAULT 0
);


--
-- Name: purchase_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.purchase_invoices ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.purchase_invoices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: purchase_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_items (
    id integer NOT NULL,
    purchase_id integer NOT NULL,
    product_id integer NOT NULL,
    qty integer NOT NULL,
    unit_cost_base numeric(10,3) NOT NULL,
    line_subtotal numeric(10,3) NOT NULL,
    allocated_extra_cost numeric(10,3) DEFAULT '0'::numeric,
    unit_cost_final numeric(10,3) DEFAULT '0'::numeric,
    variant_id integer
);


--
-- Name: purchase_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.purchase_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.purchase_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sale_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_items (
    id integer NOT NULL,
    sale_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(10,3) NOT NULL,
    total numeric(10,3) NOT NULL,
    unit_cost_at_sale numeric(10,3) DEFAULT 0,
    line_cogs numeric(10,3) DEFAULT 0
);


--
-- Name: sale_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sale_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sale_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sale_return_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_return_items (
    id integer NOT NULL,
    return_id integer NOT NULL,
    sale_item_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(10,3) NOT NULL,
    unit_cost numeric(10,3) DEFAULT '0'::numeric,
    line_total numeric(10,3) NOT NULL,
    line_cogs numeric(10,3) DEFAULT '0'::numeric
);


--
-- Name: sale_return_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sale_return_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sale_return_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sale_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_returns (
    id integer NOT NULL,
    return_number text NOT NULL,
    sale_id integer NOT NULL,
    branch_id integer NOT NULL,
    shift_id integer,
    refund_amount numeric(10,3) NOT NULL,
    refund_method text DEFAULT 'cash'::text NOT NULL,
    cogs_returned numeric(10,3) DEFAULT '0'::numeric,
    reason text,
    created_by integer,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: sale_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sale_returns ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sale_returns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales (
    id integer NOT NULL,
    invoice_number text NOT NULL,
    branch_id integer NOT NULL,
    cashier_id integer,
    customer_id integer,
    subtotal numeric(10,3) NOT NULL,
    discount numeric(10,3) DEFAULT '0'::numeric,
    discount_type text DEFAULT 'value'::text,
    vat numeric(10,3) NOT NULL,
    total numeric(10,3) NOT NULL,
    payment_method text DEFAULT 'cash'::text NOT NULL,
    bank_txn_id text,
    bank_receipt_image text,
    created_at timestamp without time zone DEFAULT now(),
    shift_id integer,
    cogs_total numeric(10,3) DEFAULT '0'::numeric,
    gross_profit numeric(10,3) DEFAULT '0'::numeric
);


--
-- Name: sales_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sales ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sales_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


--
-- Name: shifts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shifts (
    id integer NOT NULL,
    branch_id integer NOT NULL,
    cashier_id integer NOT NULL,
    started_at timestamp without time zone DEFAULT now(),
    ended_at timestamp without time zone,
    total_sales numeric(10,3) DEFAULT '0'::numeric,
    total_cash numeric(10,3) DEFAULT '0'::numeric,
    total_bank numeric(10,3) DEFAULT '0'::numeric,
    status text DEFAULT 'open'::text,
    opening_cash numeric(12,3) DEFAULT 0,
    terminal_name text DEFAULT 'UNKNOWN'::text NOT NULL,
    expected_cash numeric(12,3),
    difference numeric(12,3),
    actual_cash numeric(12,3)
);


--
-- Name: shifts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.shifts ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.shifts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: stock_transfer_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_transfer_lines (
    id integer NOT NULL,
    transfer_id integer NOT NULL,
    variant_id integer NOT NULL,
    qty integer NOT NULL
);


--
-- Name: stock_transfer_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.stock_transfer_lines ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.stock_transfer_lines_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: stock_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_transfers (
    id integer NOT NULL,
    from_location_id integer NOT NULL,
    to_location_id integer NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    created_by integer,
    created_at timestamp without time zone DEFAULT now(),
    approved_at timestamp without time zone
);


--
-- Name: stock_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.stock_transfers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.stock_transfers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: stocktake_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stocktake_items (
    id integer NOT NULL,
    stocktake_id integer NOT NULL,
    product_id integer NOT NULL,
    system_qty integer DEFAULT 0 NOT NULL,
    counted_qty integer,
    difference integer DEFAULT 0,
    note text
);


--
-- Name: stocktake_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.stocktake_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.stocktake_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: stocktakes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stocktakes (
    id integer NOT NULL,
    branch_id integer NOT NULL,
    location_id integer NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    note text,
    total_items integer DEFAULT 0,
    matched_items integer DEFAULT 0,
    surplus_items integer DEFAULT 0,
    shortage_items integer DEFAULT 0,
    created_by integer,
    approved_by integer,
    created_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone
);


--
-- Name: stocktakes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.stocktakes ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.stocktakes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: supplier_ocr_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_ocr_templates (
    id integer NOT NULL,
    supplier_id integer NOT NULL,
    invoice_no_pattern text,
    date_pattern text,
    table_start_keyword text,
    column_order text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: supplier_ocr_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.supplier_ocr_templates ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.supplier_ocr_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    name text NOT NULL,
    phone text,
    email text,
    address text,
    city text,
    tax_no text,
    cr_no text,
    notes text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.suppliers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.suppliers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    role text DEFAULT 'employee'::text NOT NULL,
    branch_id integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    terminal_name text DEFAULT 'T1'::text NOT NULL,
    pin text,
    phone text,
    salary numeric(10,3) DEFAULT 0,
    salary_type text DEFAULT 'monthly'::text,
    commission_rate numeric(5,2) DEFAULT 0,
    ui_language text DEFAULT 'ar'::text NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.users ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warehouses (
    id integer NOT NULL,
    name text NOT NULL,
    branch_id integer,
    is_main boolean DEFAULT false
);


--
-- Name: warehouses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.warehouses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.warehouses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, action, entity_type, entity_id, branch_id, user_id, user_name, details, old_value, new_value, ip_address, created_at) FROM stdin;
1	update	settings	0	\N	6	المالك	{"businessName":"لمسة أنوثة إكسسوارات ","vatEnabled":"true","vatRate":"5"}	\N	\N	\N	2026-03-02 13:12:35.514693
2	update	settings	0	\N	6	المالك	{"businessName":"لمسة أنوثة إكسسوارات ","currency":"OMR","decimalPlaces":"3","numberFormat":"en-US","vatEnabled":"true","vatRate":"5","vatInclusive":"true","taxRegistrationNumber":"","taxName":"ضريبة القيمة المضافة","allowEmployeeDiscount":"true","invoicePrefix":"LO","invoiceNumberDigits":"5","allowEditAfterPayment":"false","allowCancelAfterClose":"false","receiptSize":"80mm","thermalPrinter":"true","businessLogo":"","autoBackup":"true"}	\N	\N	\N	2026-03-04 05:24:29.451423
3	password_reset	user	7	1	\N	\N	إعادة تعيين كلمة مرور الموظف "كاشير تجريبي" بواسطة غير معروف	\N	\N	\N	2026-03-04 05:30:25.174576
4	password_reset	user	1	2	\N	\N	إعادة تعيين كلمة مرور الموظف "مريم" بواسطة غير معروف	\N	\N	\N	2026-03-04 05:33:13.472359
5	password_reset	user	1	2	\N	\N	إعادة تعيين كلمة مرور الموظف "مريم" بواسطة غير معروف	\N	\N	\N	2026-03-04 05:35:55.866464
6	password_reset	user	2	2	\N	\N	إعادة تعيين كلمة مرور الموظف "أحمد" بواسطة غير معروف	\N	\N	\N	2026-03-04 18:14:17.681619
7	update	settings	0	\N	6	المالك	{"businessName":"لمسة أنوثة إكسسوارات لوى","currency":"OMR","decimalPlaces":"2","numberFormat":"ar","vatEnabled":"false","vatRate":"0","vatInclusive":"true","taxRegistrationNumber":"","taxName":"ضريبة القيمة المضافة","allowEmployeeDiscount":"true","invoicePrefix":"LO","invoiceNumberDigits":"5","allowEditAfterPayment":"false","allowCancelAfterClose":"false","receiptSize":"80mm","thermalPrinter":"true","businessLogo":"","autoBackup":"true"}	\N	\N	\N	2026-03-04 18:22:23.617238
8	update	settings	0	\N	6	المالك	{"businessName":"لمسة أنوثة إكسسوارات لوى","currency":"OMR","decimalPlaces":"2","numberFormat":"en-US","vatEnabled":"false","vatRate":"0","vatInclusive":"true","taxRegistrationNumber":"","taxName":"ضريبة القيمة المضافة","allowEmployeeDiscount":"true","invoicePrefix":"LO","invoiceNumberDigits":"5","allowEditAfterPayment":"false","allowCancelAfterClose":"false","receiptSize":"80mm","thermalPrinter":"true","businessLogo":"","autoBackup":"true"}	\N	\N	\N	2026-03-04 18:22:31.374318
9	update	settings	0	\N	6	المالك	{"businessName":"لمسة أنوثة إكسسوارات لوى","currency":"OMR","decimalPlaces":"2","numberFormat":"en-US","vatEnabled":"false","vatRate":"0","vatInclusive":"false","taxRegistrationNumber":"","taxName":"ضريبة القيمة المضافة","allowEmployeeDiscount":"true","invoicePrefix":"LO","invoiceNumberDigits":"5","allowEditAfterPayment":"false","allowCancelAfterClose":"false","receiptSize":"80mm","thermalPrinter":"true","businessLogo":"","autoBackup":"true"}	\N	\N	\N	2026-03-04 18:22:38.635521
10	update	settings	0	\N	6	المالك	{"businessName":"لمسة أنوثة إكسسوارات لوى","currency":"OMR","decimalPlaces":"2","numberFormat":"en-US","vatEnabled":"false","vatRate":"0","vatInclusive":"false","taxRegistrationNumber":"","taxName":"ضريبة القيمة المضافة","allowEmployeeDiscount":"false","invoicePrefix":"LO","invoiceNumberDigits":"5","allowEditAfterPayment":"false","allowCancelAfterClose":"false","receiptSize":"80mm","thermalPrinter":"true","businessLogo":"","autoBackup":"true"}	\N	\N	\N	2026-03-04 18:22:46.43882
11	update	settings	0	\N	6	المالك	{"businessName":"لمسة أنوثة إكسسوارات لوى","currency":"OMR","decimalPlaces":"2","numberFormat":"en-US","vatEnabled":"false","vatRate":"0","vatInclusive":"false","taxRegistrationNumber":"","taxName":"ضريبة القيمة المضافة","allowEmployeeDiscount":"false","invoicePrefix":"LO","invoiceNumberDigits":"5","allowEditAfterPayment":"true","allowCancelAfterClose":"true","receiptSize":"80mm","thermalPrinter":"true","businessLogo":"","autoBackup":"true"}	\N	\N	\N	2026-03-04 18:23:19.092986
\.


--
-- Data for Name: bank_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_ledger (id, date, branch_id, shift_id, method, amount_in, amount_out, ref_id, note, created_by, created_at, category) FROM stdin;
1	2026-03-02	1	29	card	20.000	0.000	\N	دفع طلب TEST-CARD-100	\N	2026-03-02 03:04:39.932374	\N
2	2026-03-02	1	29	bank_transfer	30.000	0.000	BT-9999	دفع طلب TEST-BANK-100	\N	2026-03-02 03:04:40.055231	\N
3	2026-03-02	1	37	card	20.000	0.000	\N	بيع فاتورة TEST-CARD-L1	6	2026-03-02 03:56:58.247238	sale
4	2026-03-02	1	37	bank_transfer	30.000	0.000	BT-TEST-999	بيع فاتورة TEST-BT-L1	6	2026-03-02 03:56:58.434711	sale
5	2026-03-02	1	40	bank_transfer	0.000	50.000	\N	إيجار المحل شهر مارس	6	2026-03-02 08:52:28.607267	rent
6	2026-03-04	1	40	card	0.000	900.000	\N	فاتورة مكتب 	6	2026-03-04 05:25:40.461687	electricity
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branches (id, name, address, is_main) FROM stdin;
1	لمسة أنوثة إكسسوارات لوى	ولاية لوى، الشارع العام	t
2	لمسة أنوثة شناص	ولاية شناص، بجوار المركز الصحي	f
3	لمسة أنوثة (الفرع الثالث)		f
\.


--
-- Data for Name: cash_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cash_ledger (id, date, branch_id, shift_id, type, amount_in, amount_out, note, created_by, created_at, category) FROM stdin;
1	2026-03-02	1	29	order_payment	10.000	0.000	دفع طلب TEST-CASH-100	\N	2026-03-02 03:04:39.815368	\N
2	2026-03-02	1	29	expense	0.000	2.000	شراء أكياس	\N	2026-03-02 03:05:17.23592	\N
3	2026-03-02	1	29	shift_difference	1.000	0.000	فرق إغلاق شفت #29	\N	2026-03-02 03:05:27.944519	\N
4	2026-03-02	1	34	shift_difference	50.000	0.000	فرق إغلاق شفت #34	\N	2026-03-02 03:41:49.625728	\N
5	2026-03-02	1	35	expense	0.000	2.000	شراء أكياس	6	2026-03-02 03:53:48.03872	misc
6	2026-03-02	1	35	shift_difference	10.000	0.000	فرق إغلاق شفت #35	\N	2026-03-02 03:53:48.190287	\N
7	2026-03-02	1	36	expense	0.000	2.000	شراء أكياس	6	2026-03-02 03:56:05.175669	misc
8	2026-03-02	1	36	shift_difference	10.000	0.000	فرق إغلاق شفت #36	\N	2026-03-02 03:56:05.331543	\N
9	2026-03-02	1	37	sale	10.000	0.000	بيع فاتورة TEST-CASH-L1	6	2026-03-02 03:56:58.137448	sale
10	2026-03-02	1	37	expense	0.000	2.000	شراء أكياس	6	2026-03-02 03:56:58.525506	misc
11	2026-03-02	1	38	sale	11.235	0.000	بيع فاتورة INV-1772424181648	6	2026-03-02 04:03:03.677479	sale
12	2026-03-02	1	38	sale	30.870	0.000	بيع فاتورة INV-1772425450036	6	2026-03-02 04:24:12.183156	sale
13	2026-03-02	1	38	sale	12.600	0.000	بيع فاتورة TEST-001	6	2026-03-02 06:59:59.127891	sale
14	2026-03-02	1	38	deposit	5.000	0.000	إيداع تجريبي	6	2026-03-02 08:30:21.475542	إيداع
15	2026-03-02	1	38	withdrawal	0.000	2.000	سحب تجريبي	6	2026-03-02 08:30:21.589419	سحب
16	2026-03-02	1	38	shift_difference	0.000	57.995	فرق إغلاق شفت #38	\N	2026-03-02 08:43:30.50191	\N
17	2026-03-02	1	40	expense	0.000	5.500	فاتورة كهرباء الشهر	6	2026-03-02 08:52:13.437911	electricity
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name) FROM stdin;
1	عقود
2	أساور
3	خواتم
4	حلقان
5	أطقم
\.


--
-- Data for Name: cities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cities (id, name, branch_id) FROM stdin;
1	لوى	1
2	صحار	1
3	شناص	2
4	صحم	2
5	مسقط	1
6	بركاء	3
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, phone, city, address, total_spent, visits, last_visit, created_at) FROM stdin;
1	\N	97774471	\N	\N	0.000	0	\N	2026-03-04 06:17:46.598815
2	\N	97775569	\N	\N	0.000	0	\N	2026-03-04 18:19:25.218857
3	\N	98889670	\N	\N	0.000	0	\N	2026-03-05 08:06:11.24609
4	ثبسيبسي	98888899	\N	\N	0.000	0	\N	2026-03-05 08:07:13.203273
\.


--
-- Data for Name: employee_advances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_advances (id, employee_id, amount, date, note, settled, settled_in_payroll_id, created_by, created_at) FROM stdin;
1	3	25.000	2026-03-01	سلفة شخصية	t	1	6	2026-03-02 11:20:24.003108
\.


--
-- Data for Name: employee_deductions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_deductions (id, employee_id, amount, reason, date, applied_in_payroll_id, created_by, created_at) FROM stdin;
1	3	5.000	تأخير	2026-03-01	1	6	2026-03-02 11:20:24.057829
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employees (id, name, phone, branch_id, salary, role) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, branch_id, category, amount, date, notes, receipt_image, created_at, shift_id, source, created_by) FROM stdin;
1	1	TEST	1.000	2026-03-01	test expense	\N	2026-03-01 08:26:52.60298	22	cash	\N
3	1	مستلزمات	2.000	2026-03-02	شراء أكياس	\N	2026-03-02 03:05:17.229787	29	cash	\N
4	1	misc	2.000	2026-03-02	شراء أكياس	\N	2026-03-02 03:53:48.034226	35	cash	\N
5	1	misc	2.000	2026-03-02	شراء أكياس	\N	2026-03-02 03:56:05.170814	36	cash	\N
6	1	misc	2.000	2026-03-02	شراء أكياس	\N	2026-03-02 03:56:58.521515	37	cash	\N
7	1	electricity	5.500	2026-03-02	فاتورة كهرباء الشهر	\N	2026-03-02 08:52:13.431848	40	cash	6
8	1	rent	50.000	2026-03-02	إيجار المحل شهر مارس	\N	2026-03-02 08:52:28.564104	40	bank_transfer	6
9	1	electricity	900.000	2026-03-04	فاتورة مكتب 	\N	2026-03-04 05:25:40.420919	40	card	6
\.


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory (id, product_id, warehouse_id, quantity, min_quantity) FROM stdin;
2	1	2	6	5
3	1	3	11	5
5	2	2	28	5
6	2	3	4	5
8	3	2	17	5
9	3	3	14	5
10	4	1	93	5
11	4	2	27	5
12	4	3	12	5
13	5	1	146	5
14	5	2	8	5
15	5	3	8	5
17	6	2	17	5
18	6	3	8	5
20	7	2	21	5
21	7	3	9	5
23	8	2	32	5
24	8	3	4	5
4	2	1	132	5
7	3	1	70	5
16	6	1	142	5
19	7	1	133	5
22	8	1	106	5
1	1	1	113	5
\.


--
-- Data for Name: inventory_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_adjustments (id, branch_id, location_id, product_id, type, qty_before, qty_change, qty_after, reason, stocktake_id, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: inventory_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_balances (id, location_id, variant_id, qty_on_hand, qty_reserved) FROM stdin;
1	7	6	10	0
3	7	9	700	0
4	7	3	1	0
5	7	7	38	0
6	7	2	20	0
7	7	52	12	0
8	7	53	220	0
9	7	54	5	0
10	7	55	6	0
11	7	56	11312	0
12	7	57	11	0
13	7	58	13	0
14	7	59	15142	0
15	7	60	18	0
16	7	62	25	0
2	7	1	305	0
\.


--
-- Data for Name: inventory_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_ledger (id, variant_id, location_id, qty_change, reason, ref_table, ref_id, created_by, created_at) FROM stdin;
1	6	7	10	purchase_posted	purchase_invoices	1	6	2026-03-04 08:41:01.882418
2	1	7	5	purchase_posted	purchase_invoices	1	6	2026-03-04 08:41:01.882418
3	9	7	700	purchase_posted	purchase_invoices	2	6	2026-03-04 08:41:01.882418
4	3	7	1	purchase_posted	purchase_invoices	3	6	2026-03-04 08:41:01.882418
5	7	7	38	purchase_posted	purchase_invoices	4	6	2026-03-04 08:41:01.882418
6	2	7	20	purchase_posted	purchase_invoices	5	6	2026-03-04 08:41:01.882418
7	52	7	12	purchase_posted	purchase_invoices	7	6	2026-03-04 08:41:01.882418
8	53	7	220	purchase_posted	purchase_invoices	7	6	2026-03-04 08:41:01.882418
9	54	7	5	purchase_posted	purchase_invoices	7	6	2026-03-04 08:41:01.882418
10	55	7	6	purchase_posted	purchase_invoices	7	6	2026-03-04 08:41:01.882418
11	56	7	11312	purchase_posted	purchase_invoices	7	6	2026-03-04 08:41:01.882418
12	57	7	11	purchase_posted	purchase_invoices	7	6	2026-03-04 08:41:01.882418
13	58	7	13	purchase_posted	purchase_invoices	7	6	2026-03-04 08:41:01.882418
14	59	7	15142	purchase_posted	purchase_invoices	7	6	2026-03-04 08:41:01.882418
15	60	7	18	purchase_posted	purchase_invoices	7	6	2026-03-04 08:41:01.882418
16	62	7	25	purchase_posted	purchase_invoices	7	6	2026-03-04 08:41:01.882418
17	1	7	300	purchase_posted	purchase_invoices	8	6	2026-03-04 08:41:01.882418
\.


--
-- Data for Name: inventory_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_transactions (id, date, branch_id, from_location_id, to_location_id, product_id, type, qty, ref_table, ref_id, note, created_by, created_at) FROM stdin;
1	2026-03-02	1	\N	2	1	manual_receipt	5	\N	\N	استلام يدوي	6	2026-03-02 04:49:06.073354
2	2026-03-02	1	\N	2	7	purchase_receipt	700	purchase_invoices	2	استلام مشتريات فاتورة PUR-1772428759329	6	2026-03-02 05:25:36.52732
3	2026-03-02	\N	\N	7	8	PURCHASE	1	purchase_invoices	3	اعتماد فاتورة شراء	6	2026-03-02 06:49:58.84083
6	2026-03-02	1	2	\N	1	SALE	1	sales	30	بيع فاتورة TEST-001	6	2026-03-02 06:59:59.103614
7	2026-03-02	\N	\N	7	3	PURCHASE	38	purchase_invoices	4	اعتماد فاتورة شراء	6	2026-03-02 08:12:34.75991
14	2026-03-02	\N	\N	7	5	PURCHASE	20	purchase_invoices	5	اعتماد فاتورة شراء	6	2026-03-02 08:19:59.979771
4	2026-03-02	1	7	\N	8	TRANSFER_OUT	1	location_transfers	1	صادر من المخزن المركزي إلى لمسة أنوثة إكسسوارات لوى	6	2026-03-02 06:50:36.331807
5	2026-03-02	1	\N	2	8	TRANSFER_IN	1	location_transfers	1	وارد من المخزن المركزي إلى لمسة أنوثة إكسسوارات لوى	6	2026-03-02 06:50:36.331807
8	2026-03-02	1	7	\N	3	TRANSFER_OUT	5	location_transfers	10	صادر من المخزن المركزي إلى لمسة أنوثة إكسسوارات لوى	6	2026-03-02 08:13:56.166593
9	2026-03-02	1	\N	2	3	TRANSFER_IN	5	location_transfers	10	وارد من المخزن المركزي إلى لمسة أنوثة إكسسوارات لوى	6	2026-03-02 08:13:56.166593
10	2026-03-02	2	7	\N	1	TRANSFER_OUT	3	location_transfers	11	صادر من المخزن المركزي إلى لمسة أنوثة شناص	6	2026-03-02 08:19:23.442376
11	2026-03-02	2	\N	4	1	TRANSFER_IN	3	location_transfers	11	وارد من المخزن المركزي إلى لمسة أنوثة شناص	6	2026-03-02 08:19:23.442376
12	2026-03-02	1	7	\N	7	TRANSFER_OUT	50	location_transfers	12	صادر من المخزن المركزي إلى لمسة أنوثة إكسسوارات لوى	6	2026-03-02 08:19:23.541421
13	2026-03-02	1	\N	2	7	TRANSFER_IN	50	location_transfers	12	وارد من المخزن المركزي إلى لمسة أنوثة إكسسوارات لوى	6	2026-03-02 08:19:23.541421
15	2026-03-02	3	7	\N	5	TRANSFER_OUT	8	location_transfers	15	صادر من المخزن المركزي إلى لمسة أنوثة (الفرع الثالث)	6	2026-03-02 08:20:00.139182
16	2026-03-02	3	\N	6	5	TRANSFER_IN	8	location_transfers	15	وارد من المخزن المركزي إلى لمسة أنوثة (الفرع الثالث)	6	2026-03-02 08:20:00.139182
17	2026-03-02	2	7	\N	3	TRANSFER_OUT	20	location_transfers	16	صادر من المخزن المركزي إلى لمسة أنوثة شناص	6	2026-03-02 08:20:02.654046
18	2026-03-02	2	\N	4	3	TRANSFER_IN	20	location_transfers	16	وارد من المخزن المركزي إلى لمسة أنوثة شناص	6	2026-03-02 08:20:02.654046
20	2026-03-04	\N	\N	7	54	PURCHASE	12	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:31:19.073947
21	2026-03-04	\N	\N	7	55	PURCHASE	220	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:31:19.073947
22	2026-03-04	\N	\N	7	56	PURCHASE	5	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:31:19.073947
23	2026-03-04	\N	\N	7	57	PURCHASE	6	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:31:19.073947
24	2026-03-04	\N	\N	7	58	PURCHASE	11312	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:31:19.073947
25	2026-03-04	\N	\N	7	59	PURCHASE	11	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:31:19.073947
26	2026-03-04	\N	\N	7	61	PURCHASE	15142	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:31:19.073947
27	2026-03-04	\N	\N	7	64	PURCHASE	25	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:31:19.073947
28	2026-03-04	\N	\N	7	62	PURCHASE	18	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:31:19.073947
29	2026-03-04	\N	\N	7	60	PURCHASE	13	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:31:19.073947
30	2026-03-04	\N	\N	7	54	PURCHASE	12	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:36:48.087219
31	2026-03-04	\N	\N	7	55	PURCHASE	220	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:36:48.087219
32	2026-03-04	\N	\N	7	56	PURCHASE	5	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:36:48.087219
33	2026-03-04	\N	\N	7	57	PURCHASE	6	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:36:48.087219
34	2026-03-04	\N	\N	7	58	PURCHASE	11312	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:36:48.087219
35	2026-03-04	\N	\N	7	59	PURCHASE	11	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:36:48.087219
36	2026-03-04	\N	\N	7	61	PURCHASE	15142	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:36:48.087219
37	2026-03-04	\N	\N	7	64	PURCHASE	25	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:36:48.087219
38	2026-03-04	\N	\N	7	62	PURCHASE	18	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:36:48.087219
39	2026-03-04	\N	\N	7	60	PURCHASE	13	purchase_invoices	7	اعتماد فاتورة شراء	6	2026-03-04 08:36:48.087219
40	2026-03-04	\N	\N	7	2	PURCHASE	300	purchase_invoices	8	اعتماد فاتورة شراء	6	2026-03-04 08:38:28.146573
\.


--
-- Data for Name: inventory_transfers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_transfers (id, product_id, from_warehouse_id, to_warehouse_id, quantity, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: location_inventory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.location_inventory (id, location_id, product_id, qty_on_hand, reorder_level, updated_at) FROM stdin;
4	2	8	1	5	2026-03-02 06:50:36.331807
1	2	1	4	5	2026-03-02 06:59:59.103614
6	2	3	5	5	2026-03-02 08:13:56.166593
3	7	8	1	5	2026-03-02 08:19:07.079767
7	7	1	7	5	2026-03-02 08:19:23.442376
12	4	1	3	5	2026-03-02 08:19:23.442376
10	7	7	650	5	2026-03-02 08:19:23.541421
2	2	7	750	5	2026-03-02 08:19:23.541421
14	7	5	12	5	2026-03-02 08:20:00.139182
15	6	5	8	5	2026-03-02 08:20:00.139182
5	7	3	13	5	2026-03-02 08:20:02.654046
16	4	3	20	5	2026-03-02 08:20:02.654046
18	7	54	24	5	2026-03-04 08:36:48.087219
19	7	55	440	5	2026-03-04 08:36:48.087219
20	7	56	10	5	2026-03-04 08:36:48.087219
21	7	57	12	5	2026-03-04 08:36:48.087219
22	7	58	22624	5	2026-03-04 08:36:48.087219
23	7	59	22	5	2026-03-04 08:36:48.087219
24	7	61	30284	5	2026-03-04 08:36:48.087219
25	7	64	50	5	2026-03-04 08:36:48.087219
26	7	62	36	5	2026-03-04 08:36:48.087219
27	7	60	26	5	2026-03-04 08:36:48.087219
8	7	2	305	5	2026-03-04 08:38:28.146573
\.


--
-- Data for Name: location_transfer_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.location_transfer_items (id, transfer_id, product_id, qty) FROM stdin;
1	1	8	1
2	10	3	5
3	11	1	3
4	12	7	50
5	15	5	8
6	16	3	20
\.


--
-- Data for Name: location_transfers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.location_transfers (id, branch_id, from_location_id, to_location_id, note, created_by, created_at) FROM stdin;
1	1	7	2	تحويل من المخزن المركزي إلى لمسة أنوثة إكسسوارات لوى	6	2026-03-02 06:50:36.331807
10	1	7	2	تحويل من المخزن المركزي إلى لمسة أنوثة إكسسوارات لوى	6	2026-03-02 08:13:56.166593
11	2	7	4	تحويل من المخزن المركزي إلى لمسة أنوثة شناص	6	2026-03-02 08:19:23.442376
12	1	7	2	تحويل من المخزن المركزي إلى لمسة أنوثة إكسسوارات لوى	6	2026-03-02 08:19:23.541421
15	3	7	6	تحويل من المخزن المركزي إلى لمسة أنوثة (الفرع الثالث)	6	2026-03-02 08:20:00.139182
16	2	7	4	تحويل من المخزن المركزي إلى لمسة أنوثة شناص	6	2026-03-02 08:20:02.654046
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.locations (id, branch_id, code, name, active, type, is_main, kind, is_central, is_branch_default) FROM stdin;
1	1	showroom	صالة العرض	t	SHOWROOM	f	BRANCH_SHOWROOM	f	f
3	2	showroom	صالة العرض	t	SHOWROOM	f	BRANCH_SHOWROOM	f	f
5	3	showroom	صالة العرض	t	SHOWROOM	f	BRANCH_SHOWROOM	f	f
2	1	backstore	المخزن	t	MAIN_WAREHOUSE	t	BRANCH_STORE	f	t
4	2	backstore	المخزن	t	MAIN_WAREHOUSE	t	BRANCH_STORE	f	t
6	3	backstore	المخزن	t	MAIN_WAREHOUSE	t	BRANCH_STORE	f	t
7	\N	central	المخزن المركزي	t	CENTRAL	f	CENTRAL	t	f
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, order_id, product_id, quantity, unit_price, total, unit_cost_at_sale, line_cogs) FROM stdin;
1	17	1	1	5.000	5.000	0.000	0.000
2	18	1	1	10.000	10.000	0.000	0.000
3	19	2	1	20.000	20.000	0.000	0.000
4	20	3	1	30.000	30.000	0.000	0.000
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, order_number, customer_name, customer_phone, city, address, branch_id, delivery_type, status, total, notes, created_at, shift_id, payment_method, bank_txn_id, paid_at, cogs_total, gross_profit, employee_id) FROM stdin;
10	ORD-20260228-134813	عميل نقدي	0000000	\N	\N	1	pickup	paid	25.000	\N	2026-02-28 13:48:13.701279	18	cash	\N	2026-02-28 13:48:13.701279	0.000	0.000	\N
11	ORD-20260228-135420	عميل نقدي	0000000	\N	\N	1	pickup	paid	25.000	\N	2026-02-28 13:54:20.310358	20	cash	\N	2026-02-28 13:57:39.324503	0.000	0.000	\N
7	BR1-POS-1-ORD-000003	Sarah	90000000	Muscat	Al Khuwair	1	delivery	paid	10.000	ملاحظة	2026-02-28 07:33:15.51122	17	cash	\N	\N	0.000	0.000	\N
5	BR1-POS-1-ORD-000001	Test	\N	\N	\N	1	pickup	cancelled	0.000	\N	2026-02-28 07:32:33.289415	17	cash	\N	\N	0.000	0.000	\N
6	BR1-POS-1-ORD-000002	Sarah	90000000	Muscat	Al Khuwair	1	delivery	cancelled	10.000	ملاحظة	2026-02-28 07:33:12.410211	17	cash	\N	\N	0.000	0.000	\N
13	T-BANK-001	Walk-in	00000000	Muscat	-	1	store	paid	30.000	test bank transfer	2026-03-01 05:03:33.195482	24	bank_transfer	BANK-TEST-001	\N	0.000	0.000	\N
15	T-CARD-001	Test Customer	\N	\N	\N	1	pickup	paid	15.000	\N	2026-03-01 05:14:14.531365	25	card	\N	\N	0.000	0.000	\N
14	T-CASH-001	Test Customer	\N	\N	\N	1	pickup	paid	20.000	\N	2026-03-01 05:13:59.228415	25	cash	\N	\N	0.000	0.000	\N
17	TEST-SHIFT-001	اختبار ربط الشفت	99887766	\N	\N	1	pickup	completed	5.000	\N	2026-03-02 02:57:24.142013	28	cash	\N	\N	0.000	0.000	\N
18	TEST-CASH-100	عميل نقدي	\N	\N	\N	1	pickup	paid	10.000	\N	2026-03-02 03:04:29.889647	29	cash	\N	2026-03-02 03:04:39.809	0.000	0.000	\N
19	TEST-CARD-100	عميل بطاقة	\N	\N	\N	1	pickup	paid	20.000	\N	2026-03-02 03:04:29.980628	29	card	\N	2026-03-02 03:04:39.927	0.000	0.000	\N
20	TEST-BANK-100	عميل تحويل	\N	\N	\N	1	pickup	ready	30.000	\N	2026-03-02 03:04:30.075504	29	bank_transfer	BT-9999	2026-03-02 03:04:40.05	0.000	0.000	\N
21	ORD-029613	ثبسيبسي	98888899	لوى	يشيشسيش	1	delivery	new	3333.000		2026-03-05 08:07:13.078453	40	cash	\N	\N	0.000	0.000	6
\.


--
-- Data for Name: payroll_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_details (id, payroll_id, employee_id, basic_salary, commission, deductions, advances, bonus, net_salary, note) FROM stdin;
7	1	3	0.000	0.000	5.000	25.000	0.000	-30.000	\N
8	1	4	0.000	0.000	0.000	0.000	0.000	0.000	\N
9	1	5	0.000	0.000	0.000	0.000	0.000	0.000	\N
10	1	7	0.000	0.000	0.000	0.000	0.000	0.000	\N
11	1	8	0.000	0.000	0.000	0.000	0.000	0.000	\N
12	1	9	0.000	0.000	0.000	0.000	0.000	0.000	\N
\.


--
-- Data for Name: payroll_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_runs (id, month, year, status, total_basic, total_commission, total_deductions, total_advances, total_net, note, created_by, approved_by, created_at, approved_at) FROM stdin;
1	3	2026	approved	0.000	0.000	5.000	25.000	-30.000	\N	6	6	2026-03-02 11:20:05.033166	2026-03-02 11:20:33.055
\.


--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_variants (id, product_id, sku, barcode, color, size, cost_default, price, active, created_at) FROM stdin;
1	2	SKU-2	893456789002	\N	\N	1.367	8.500	t	2026-03-04 07:21:36.856085
2	5	SKU-5	893456789005	\N	\N	3.500	15.000	t	2026-03-04 07:21:36.856085
3	8	SKU-8	893456789008	\N	\N	0.001	9.800	t	2026-03-04 07:21:36.856085
4	6	SKU-6	893456789006	\N	\N	0.000	6.500	t	2026-03-04 07:21:36.856085
5	4	SKU-4	893456789004	\N	\N	0.000	45.000	t	2026-03-04 07:21:36.856085
6	1	SKU-1	893456789001	\N	\N	3.417	12.000	t	2026-03-04 07:21:36.856085
7	3	SKU-3	893456789003	\N	\N	0.260	5.000	t	2026-03-04 07:21:36.856085
8	9	SKU-9	PRD-9	\N	\N	0.000	3.000	t	2026-03-04 07:21:36.856085
9	7	SKU-7	893456789007	\N	\N	6.004	4.200	t	2026-03-04 07:21:36.856085
10	12	SKU-10-1772699371	BC-10-1772699422	1	1	20.000	20.000	t	2026-03-04 07:53:51.958742
11	13	SKU-11-1772699371	BC-11-1772699422	\N	\N	45220.000	45220.000	t	2026-03-04 07:53:52.637217
12	14	SKU-12-1772699371	BC-12-1772699422	pwrzozssapiackrians	\N	30.000	30.000	t	2026-03-04 07:53:53.322526
13	15	SKU-13-1772699371	BC-13-1772699422	قصد	\N	422.000	422.000	t	2026-03-04 07:53:54.039624
14	16	SKU-14-1772699371	BC-14-1772699422	\N	\N	2.000	2.000	t	2026-03-04 07:53:54.727279
15	17	SKU-15-1772699371	BC-15-1772699422	Jsoescorreetnins	\N	20.000	20.000	t	2026-03-04 07:53:55.4313
16	18	SKU-16-1772699371	BC-16-1772699422	7	7	20.000	20.000	t	2026-03-04 07:53:56.116888
17	19	SKU-17-1772699371	BC-17-1772699422	8	8	30.000	30.000	t	2026-03-04 07:53:56.835453
18	20	SKU-18-1772699371	BC-18-1772699422	قفي	\N	2.000	2.000	t	2026-03-04 07:53:57.516335
19	21	SKU-19-1772699371	BC-19-1772699422	10	10	80.000	80.000	t	2026-03-04 07:53:58.191659
20	22	SKU-20-1772699371	BC-20-1772699422	jezrooomzes	\N	30.000	30.000	t	2026-03-04 07:53:58.879356
21	23	SKU-21-1772699371	BC-21-1772699422	12	12	80.000	80.000	t	2026-03-04 07:53:59.556422
22	24	SKU-22-1772699371	BC-22-1772699422	13	13	320.000	320.000	t	2026-03-04 07:54:00.256121
23	25	SKU-23-1772699371	BC-23-1772699422	14	14	30.000	30.000	t	2026-03-04 07:54:01.012905
24	26	SKU-24-1772699371	BC-24-1772699422	0	0	320.000	320.000	t	2026-03-04 07:54:01.695758
25	27	SKU-25-1772699371	BC-25-1772699422	\N	\N	2.000	2.000	t	2026-03-04 07:54:02.37018
26	28	SKU-26-1772699371	BC-26-1772699422	0	0	320.000	320.000	t	2026-03-04 07:54:03.055747
27	29	SKU-27-1772699371	BC-27-1772699422	\N	\N	530.000	530.000	t	2026-03-04 07:54:03.73654
28	30	SKU-28-1772699371	BC-28-1772699422	jsoeacorreetianss	\N	30.000	30.000	t	2026-03-04 07:54:04.446077
29	31	SKU-29-1772699371	BC-29-1772699422	fetzopiackzaz	\N	20.000	20.000	t	2026-03-04 07:54:05.128358
30	32	SKU-30-1772699371	BC-30-1772699422	\N	\N	30.000	30.000	t	2026-03-04 07:54:05.808017
31	33	SKU-31-1772699371	BC-31-1772699422	1	1	20.000	20.000	t	2026-03-04 08:05:10.05274
32	34	SKU-32-1772699371	BC-32-1772699422	\N	\N	45220.000	45220.000	t	2026-03-04 08:05:10.755197
33	35	SKU-33-1772699371	BC-33-1772699422	pwrzozssapiackrians	\N	30.000	30.000	t	2026-03-04 08:05:11.471442
34	36	SKU-34-1772699371	BC-34-1772699422	قصد	\N	422.000	422.000	t	2026-03-04 08:05:12.349068
35	37	SKU-35-1772699371	BC-35-1772699422	\N	\N	2.000	2.000	t	2026-03-04 08:05:13.037909
36	38	SKU-36-1772699371	BC-36-1772699422	Jsoescorreetnins	\N	20.000	20.000	t	2026-03-04 08:05:13.780811
37	39	SKU-37-1772699371	BC-37-1772699422	7	7	20.000	20.000	t	2026-03-04 08:05:14.646224
38	40	SKU-38-1772699371	BC-38-1772699422	8	8	30.000	30.000	t	2026-03-04 08:05:15.348522
39	41	SKU-39-1772699371	BC-39-1772699422	قفي	\N	2.000	2.000	t	2026-03-04 08:05:16.229542
40	42	SKU-40-1772699371	BC-40-1772699422	10	10	80.000	80.000	t	2026-03-04 08:05:17.109028
41	43	SKU-41-1772699371	BC-41-1772699422	jezrooomzes	\N	30.000	30.000	t	2026-03-04 08:05:17.813988
42	44	SKU-42-1772699371	BC-42-1772699422	12	12	80.000	80.000	t	2026-03-04 08:05:18.522039
43	45	SKU-43-1772699371	BC-43-1772699422	13	13	320.000	320.000	t	2026-03-04 08:05:19.225394
44	46	SKU-44-1772699371	BC-44-1772699422	14	14	30.000	30.000	t	2026-03-04 08:05:19.922505
45	47	SKU-45-1772699371	BC-45-1772699422	0	0	320.000	320.000	t	2026-03-04 08:05:20.730098
46	48	SKU-46-1772699371	BC-46-1772699422	\N	\N	2.000	2.000	t	2026-03-04 08:05:21.706346
47	49	SKU-47-1772699371	BC-47-1772699422	0	0	320.000	320.000	t	2026-03-04 08:05:22.568138
48	50	SKU-48-1772699371	BC-48-1772699422	\N	\N	530.000	530.000	t	2026-03-04 08:05:23.435994
49	51	SKU-49-1772699371	BC-49-1772699422	jsoeacorreetianss	\N	30.000	30.000	t	2026-03-04 08:05:24.142415
50	52	SKU-50-1772699371	BC-50-1772699422	fetzopiackzaz	\N	20.000	20.000	t	2026-03-04 08:05:24.864722
51	53	SKU-51-1772699371	BC-51-1772699422	\N	\N	30.000	30.000	t	2026-03-04 08:05:25.581065
52	54	SKU-52-1772699371	BC-52-1772699422	[	\N	220.000	220.000	t	2026-03-04 08:27:09.374388
53	55	SKU-53-1772699371	BC-53-1772699422	2401-1	345ل فاه‎	220.000	220.000	t	2026-03-04 08:27:10.070039
54	56	SKU-54-1772699371	BC-54-1772699422	[	w2	8.000	8.000	t	2026-03-04 08:27:10.78831
55	57	SKU-55-1772699371	BC-55-1772699422	11414	1 ‏ددا‎	6.000	6.000	t	2026-03-04 08:27:11.470724
56	58	SKU-56-1772699371	BC-56-1772699422	\N	\N	0.002	0.002	t	2026-03-04 08:27:12.171352
57	59	SKU-57-1772699371	BC-57-1772699422	11	11	8.000	8.000	t	2026-03-04 08:27:12.961489
58	60	SKU-58-1772699371	BC-58-1772699422	13	13	9.000	9.000	t	2026-03-04 08:27:13.717129
59	61	SKU-59-1772699371	BC-59-1772699422	15	15	7.000	7.000	t	2026-03-04 08:27:14.402155
60	62	SKU-60-1772699371	BC-60-1772699422	18	18	90.000	90.000	t	2026-03-04 08:27:15.153545
61	63	SKU-61-1772699371	BC-61-1772699422	21	21	80.000	80.000	t	2026-03-04 08:27:15.835312
62	64	SKU-62-1772699371	BC-62-1772699422	23	23	9.000	9.000	t	2026-03-04 08:27:16.519787
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, barcode, name, category_id, price, image, active, branch_id, avg_cost, stock_qty) FROM stdin;
2	893456789002	إسورة لؤلؤ زراعي	2	8.500	\N	t	1	0.151	305
4	893456789004	طقم زفاف ناعم	5	45.000	\N	t	1	0.000	0
6	893456789006	سلسال فراشة	1	6.500	\N	t	1	0.000	0
1	893456789001	عقد ذهبي وردي	1	12.000	\N	t	1	3.417	10
7	893456789007	إسورة جلد مطرز	2	4.200	\N	t	1	6.004	700
8	893456789008	عقد قلب كريستال	1	9.800	\N	t	1	0.001	1
3	893456789003	حلق ألماس صناعي	4	5.000	\N	t	1	0.260	38
5	893456789005	خاتم فضة 925	3	15.000	\N	t	1	3.500	20
9		خاتم فضة 450	2	3.000	\N	t	\N	0.000	0
14	\N	‏ما‎	\N	30.000	\N	t	\N	0.000	0
15	\N	‏د	\N	422.000	\N	t	\N	0.000	0
16	\N	©©	\N	2.000	\N	t	\N	0.000	0
17	\N	‏قا‎	\N	20.000	\N	t	\N	0.000	0
18	\N	Item	\N	20.000	\N	t	\N	0.000	0
19	\N	Item	\N	30.000	\N	t	\N	0.000	0
20	\N	تصقثة	\N	2.000	\N	t	\N	0.000	0
21	\N	Item	\N	80.000	\N	t	\N	0.000	0
22	\N	‏قدا‎	\N	30.000	\N	t	\N	0.000	0
23	\N	Item	\N	80.000	\N	t	\N	0.000	0
24	\N	Item	\N	320.000	\N	t	\N	0.000	0
25	\N	Item	\N	30.000	\N	t	\N	0.000	0
26	\N	قصدا‎	\N	320.000	\N	t	\N	0.000	0
27	\N	ew	\N	2.000	\N	t	\N	0.000	0
28	\N	تقصدا‎	\N	320.000	\N	t	\N	0.000	0
29	\N	تصد	\N	530.000	\N	t	\N	0.000	0
30	\N	‏ما‎	\N	30.000	\N	t	\N	0.000	0
31	\N	[z	\N	20.000	\N	t	\N	0.000	0
32	\N	w0	\N	30.000	\N	t	\N	0.000	0
12	\N	Item	\N	20.000	\N	t	\N	0.000	0
13	\N	تقصد	\N	45220.000	\N	t	\N	0.000	0
33	\N	Item	\N	20.000	\N	t	\N	0.000	0
34	\N	تقصد	\N	45220.000	\N	t	\N	0.000	0
35	\N	‏ما‎	\N	30.000	\N	t	\N	0.000	0
36	\N	‏د	\N	422.000	\N	t	\N	0.000	0
37	\N	©©	\N	2.000	\N	t	\N	0.000	0
38	\N	‏قا‎	\N	20.000	\N	t	\N	0.000	0
39	\N	Item	\N	20.000	\N	t	\N	0.000	0
40	\N	Item	\N	30.000	\N	t	\N	0.000	0
41	\N	تصقثة	\N	2.000	\N	t	\N	0.000	0
42	\N	Item	\N	80.000	\N	t	\N	0.000	0
43	\N	‏قدا‎	\N	30.000	\N	t	\N	0.000	0
44	\N	Item	\N	80.000	\N	t	\N	0.000	0
45	\N	Item	\N	320.000	\N	t	\N	0.000	0
46	\N	Item	\N	30.000	\N	t	\N	0.000	0
47	\N	قصدا‎	\N	320.000	\N	t	\N	0.000	0
48	\N	ew	\N	2.000	\N	t	\N	0.000	0
49	\N	تقصدا‎	\N	320.000	\N	t	\N	0.000	0
50	\N	تصد	\N	530.000	\N	t	\N	0.000	0
51	\N	‏ما‎	\N	30.000	\N	t	\N	0.000	0
52	\N	[z	\N	20.000	\N	t	\N	0.000	0
53	\N	w0	\N	30.000	\N	t	\N	0.000	0
63	\N	Item	\N	80.000	\N	t	\N	0.000	0
54	\N	a0	\N	220.000	\N	t	\N	220.000	24
55	\N	3	\N	220.000	\N	t	\N	220.000	440
56	\N	nHoo2s-eamarooNt14-14	\N	8.000	\N	t	\N	8.000	10
57	\N	NH202s-64LTKHAK	\N	6.000	\N	t	\N	6.000	12
58	\N	‏قا‎	\N	0.002	\N	t	\N	0.002	22624
59	\N	Item	\N	8.000	\N	t	\N	8.000	22
61	\N	Item	\N	7.000	\N	t	\N	7.000	30284
64	\N	Item	\N	9.000	\N	t	\N	9.000	50
62	\N	Item	\N	90.000	\N	t	\N	1.000	36
60	\N	Item	\N	9.000	\N	t	\N	3.000	26
\.


--
-- Data for Name: purchase_extra_costs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_extra_costs (id, purchase_invoice_id, type, amount, notes) FROM stdin;
\.


--
-- Data for Name: purchase_invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_invoices (id, invoice_number, supplier_id, branch_id, invoice_date, shipping_cost, customs_cost, clearance_cost, other_cost, subtotal, total_extra_cost, grand_total, status, notes, created_by, created_at, received_at, total_amount) FROM stdin;
1	PUR-1772425103977	1	1	2026-03-02	5.000	3.000	2.000	1.000	30.000	11.000	41.000	received	\N	6	2026-03-02 04:18:23.979735	2026-03-02 08:12:01.93948	30.000
2	PUR-1772428759329	1	1	2026-03-02	1.000	1.000	1.000	0.000	4200.000	3.000	4203.000	received	\N	6	2026-03-02 05:19:19.338996	2026-03-02 08:12:13.786673	4200.000
3	PUR-1772434149190	1	\N	2026-03-02	0.000	0.000	0.000	0.000	0.001	0.000	0.001	received	\N	6	2026-03-02 06:49:09.193005	2026-03-02 08:12:13.881414	0.001
4	PUR-1772439091632	1	\N	2026-03-02	0.002	0.002	0.001	0.002	9.880	0.007	9.887	received	\N	6	2026-03-02 08:11:31.646479	2026-03-02 08:13:55.972009	9.880
5	PUR-1772439574670	1	\N	2026-03-02	0.000	0.000	0.000	0.000	70.000	0.000	70.000	approved	\N	6	2026-03-02 08:19:34.673593	\N	0.000
6	PUR-1772545155004	1	\N	2026-03-03	0.000	0.000	0.000	0.000	0.000	0.000	0.000	pending	\N	6	2026-03-03 13:39:15.014432	\N	0.000
7	PUR-1772608395112	1	\N	2026-03-04	0.000	0.000	0.000	0.000	157502.624	0.000	157502.624	approved	\N	6	2026-03-04 07:13:15.11413	\N	0.000
8	PUR-1772613469216	1	\N	2026-03-04	0.000	0.000	0.000	0.000	39.300	0.000	39.300	approved	\N	6	2026-03-04 08:37:49.225967	\N	0.000
\.


--
-- Data for Name: purchase_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_items (id, purchase_id, product_id, qty, unit_cost_base, line_subtotal, allocated_extra_cost, unit_cost_final, variant_id) FROM stdin;
1	1	1	10	2.500	25.000	9.167	3.417	6
2	1	2	5	1.000	5.000	1.833	1.367	1
3	2	7	700	6.000	4200.000	3.000	6.004	9
4	3	8	1	0.001	0.001	0.000	0.001	3
5	4	3	38	0.260	9.880	0.007	0.260	7
6	5	5	20	3.500	70.000	0.000	3.500	2
52	7	54	12	220.000	2640.000	0.000	220.000	52
53	7	55	220	220.000	48400.000	0.000	220.000	53
54	7	56	5	8.000	40.000	0.000	8.000	54
55	7	57	6	6.000	36.000	0.000	6.000	55
56	7	58	11312	0.002	22.624	0.000	0.002	56
57	7	59	11	8.000	88.000	0.000	8.000	57
58	7	60	13	3.000	39.000	0.000	3.000	58
59	7	61	15142	7.000	105994.000	0.000	7.000	59
60	7	62	18	1.000	18.000	0.000	1.000	60
62	7	64	25	9.000	225.000	0.000	9.000	62
63	8	2	300	0.131	39.300	0.000	0.131	1
\.


--
-- Data for Name: sale_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sale_items (id, sale_id, product_id, quantity, unit_price, total, unit_cost_at_sale, line_cogs) FROM stdin;
3	7	1	2	50.000	100.000	0.000	0.000
4	7	1	1	50.000	50.000	0.000	0.000
5	23	1	1	9.524	9.524	0.000	0.000
6	24	2	1	19.048	19.048	0.000	0.000
7	25	3	1	28.571	28.571	0.000	0.000
8	26	6	1	6.500	6.500	0.000	0.000
9	26	7	1	4.200	4.200	0.000	0.000
10	27	8	3	9.800	29.400	0.000	0.000
11	28	8	1	9.800	9.800	0.000	0.000
12	29	1	1	12.000	12.000	3.417	3.417
13	30	1	1	12.000	12.000	3.417	3.417
\.


--
-- Data for Name: sale_return_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sale_return_items (id, return_id, sale_item_id, product_id, quantity, unit_price, unit_cost, line_total, line_cogs) FROM stdin;
\.


--
-- Data for Name: sale_returns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sale_returns (id, return_number, sale_id, branch_id, shift_id, refund_amount, refund_method, cogs_returned, reason, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales (id, invoice_number, branch_id, cashier_id, customer_id, subtotal, discount, discount_type, vat, total, payment_method, bank_txn_id, bank_receipt_image, created_at, shift_id, cogs_total, gross_profit) FROM stdin;
3	INV-0001	1	1	\N	100.000	0.000	value	0.000	100.000	cash	\N	\N	2026-02-27 20:40:35.92681	9	0.000	0.000
4	INV-0001-4	1	1	\N	100.000	0.000	value	0.000	100.000	cash	\N	\N	2026-02-27 20:41:40.075416	9	0.000	0.000
5	INV-0001-5	1	1	\N	100.000	0.000	value	0.000	100.000	cash	\N	\N	2026-02-27 20:41:48.881421	9	0.000	0.000
6	INV-0001-6	1	1	\N	100.000	0.000	value	0.000	100.000	cash	\N	\N	2026-02-27 20:44:33.754444	9	0.000	0.000
7	INV-0001-7	1	1	\N	150.000	0.000	value	0.000	150.000	cash	\N	\N	2026-02-27 20:44:35.326193	9	0.000	0.000
9	BR1-TPOS-1-INV-000001	1	1	\N	10.000	0.000	value	0.000	10.000	cash	\N	\N	2026-02-28 06:20:18.334586	16	0.000	0.000
23	TEST-CASH-L1	1	6	\N	9.524	0.000	value	0.476	10.000	cash	\N	\N	2026-03-02 03:56:58.120534	37	0.000	0.000
24	TEST-CARD-L1	1	6	\N	19.048	0.000	value	0.952	20.000	card	\N	\N	2026-03-02 03:56:58.233827	37	0.000	0.000
25	TEST-BT-L1	1	6	\N	28.571	0.000	value	1.429	30.000	bank_transfer	BT-TEST-999	\N	2026-03-02 03:56:58.313247	37	0.000	0.000
26	INV-1772424181648	1	6	\N	10.700	0.000	value	0.535	11.235	cash	\N	\N	2026-03-02 04:03:03.658157	38	0.000	0.000
27	INV-1772425450036	1	6	\N	29.400	0.000	value	1.470	30.870	cash	\N	\N	2026-03-02 04:24:12.162865	38	0.000	30.870
28	INV-TEST-1772428320	1	6	\N	9.800	0.000	value	0.490	10.290	cash	\N	\N	2026-03-02 05:12:00.709105	38	0.000	0.000
29	INV-TEST-1772428330	1	6	\N	12.000	0.000	value	0.600	12.600	card	\N	\N	2026-03-02 05:12:10.806551	38	0.000	0.000
30	TEST-001	1	6	\N	12.000	0.000	value	0.600	12.600	cash	\N	\N	2026-03-02 06:59:59.103614	38	3.417	9.183
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.session (sid, sess, expire) FROM stdin;
FKBZeRiEgowotv4M8-YHdmU4N8GK255s	{"cookie":{"originalMaxAge":86400000,"expires":"2026-03-08T07:34:47.505Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":6}	2026-03-08 07:34:48
t2Kh2VoTpvR9BdL-2CfP-Gb5gbx6zwHn	{"cookie":{"originalMaxAge":86400000,"expires":"2026-03-08T07:34:15.339Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":6}	2026-03-08 07:34:16
ELpBNuaN--Bn_IolIPYtSqJhrAs3OLfz	{"cookie":{"originalMaxAge":86400000,"expires":"2026-03-08T07:29:00.591Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":6}	2026-03-08 07:34:48
\.


--
-- Data for Name: shifts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shifts (id, branch_id, cashier_id, started_at, ended_at, total_sales, total_cash, total_bank, status, opening_cash, terminal_name, expected_cash, difference, actual_cash) FROM stdin;
29	1	1	2026-03-02 03:04:19.671678	2026-03-02 03:05:27.947	60.000	10.000	50.000	closed	0.000	UNKNOWN	8.000	1.000	9.000
11	1	1	2026-02-28 03:18:44.198513	\N	0.000	0.000	0.000	closed	50.000	POS-1	\N	0.000	\N
12	1	1	2026-02-28 05:17:16.802756	\N	0.000	0.000	0.000	closed	50.000	POS-1	50.000	0.000	\N
13	1	1	2026-02-28 06:01:18.386505	\N	0.000	0.000	0.000	closed	50.000	POS-1	50.000	0.000	\N
9	1	1	2026-02-27 20:38:12.035528	\N	0.000	0.000	0.000	closed	50.000	UNKNOWN	\N	0.000	\N
1	1	1	2026-02-27 20:36:32.118136	\N	0.000	0.000	0.000	closed	50.000	UNKNOWN	\N	0.000	\N
2	1	1	2026-02-27 20:36:46.898124	\N	0.000	0.000	0.000	closed	50.000	UNKNOWN	\N	0.000	\N
3	1	1	2026-02-27 20:36:47.7871	\N	0.000	0.000	0.000	closed	50.000	UNKNOWN	\N	0.000	\N
4	1	1	2026-02-27 20:36:48.530241	\N	0.000	0.000	0.000	closed	50.000	UNKNOWN	\N	0.000	\N
5	1	1	2026-02-27 20:37:58.886252	\N	0.000	0.000	0.000	closed	50.000	UNKNOWN	\N	0.000	\N
6	1	1	2026-02-27 20:37:59.761283	\N	0.000	0.000	0.000	closed	50.000	UNKNOWN	\N	0.000	\N
7	1	1	2026-02-27 20:38:10.512528	\N	0.000	0.000	0.000	closed	50.000	UNKNOWN	\N	0.000	\N
8	1	1	2026-02-27 20:38:11.140229	\N	0.000	0.000	0.000	closed	50.000	UNKNOWN	\N	0.000	\N
14	1	1	2026-02-28 06:04:28.124553	\N	0.000	0.000	0.000	closed	50.000	POS-1	50.000	0.000	\N
15	1	1	2026-02-28 06:05:56.532922	\N	0.000	0.000	0.000	closed	50.000	POS-1	50.000	0.000	\N
16	1	1	2026-02-28 06:19:39.854295	\N	10.000	0.000	0.000	closed	50.000	POS-1	10.000	0.000	\N
17	1	1	2026-02-28 06:56:38.848015	2026-02-28 13:33:52.45227	10.000	0.000	0.000	closed	50.000	POS-1	\N	0.000	\N
18	1	1	2026-02-28 13:38:21.043678	2026-02-28 13:48:13.701279	25.000	25.000	0.000	closed	50.000	UNKNOWN	\N	0.000	\N
20	1	1	2026-02-28 13:52:36.471928	2026-02-28 13:58:23.87694	25.000	0.000	0.000	closed	50.000	POS-1	\N	0.000	\N
23	1	1	2026-03-01 04:59:11.827358	\N	0.000	0.000	0.000	closed	0.000	UNKNOWN	0.000	0.000	\N
24	1	1	2026-03-01 05:01:58.491	\N	30.000	0.000	30.000	closed	10.000	UNKNOWN	10.000	-40.000	\N
30	1	1	2026-03-02 03:15:03.809782	2026-03-02 03:30:42.655	0.000	0.000	0.000	closed	0.000	T1	0.000	0.000	0.000
25	1	1	2026-03-01 05:12:59.838103	\N	35.000	20.000	0.000	closed	10.000	UNKNOWN	30.000	0.000	\N
22	1	1	2026-03-01 04:46:45.260672	\N	15.500	12.500	0.000	closed	0.000	UNKNOWN	\N	0.000	\N
26	1	1	2026-03-01 08:19:52.42636	2026-03-01 08:22:45.019004	0.000	0.000	0.000	closed	0.000	T1	\N	0.000	\N
28	1	1	2026-03-01 08:38:10.544097	2026-03-02 02:57:41.261	100.000	60.000	40.000	closed	50.000	T1	\N	0.000	\N
32	1	3	2026-03-02 03:30:42.702688	2026-03-02 03:35:15.862	0.000	0.000	0.000	closed	0.000	T1	0.000	0.000	0.000
34	1	7	2026-03-02 03:41:43.895641	2026-03-02 03:41:49.628	0.000	0.000	0.000	closed	0.000	POS-2	0.000	50.000	50.000
33	1	6	2026-03-02 03:35:15.933827	2026-03-02 03:41:49.675	0.000	0.000	0.000	closed	0.000	POS-1	0.000	0.000	0.000
35	1	6	2026-03-02 03:50:52.290694	2026-03-02 03:53:48.193	0.000	0.000	0.000	closed	0.000	POS-1	-2.000	10.000	8.000
36	1	6	2026-03-02 03:56:04.866739	2026-03-02 03:56:05.333	0.000	0.000	0.000	closed	0.000	POS-1	-2.000	10.000	8.000
37	1	6	2026-03-02 03:56:58.045897	2026-03-02 03:56:58.758	60.000	10.000	50.000	closed	0.000	POS-1	8.000	0.000	8.000
38	1	6	2026-03-02 04:02:56.637889	2026-03-02 08:43:30.505	77.595	64.995	12.600	closed	0.000	POS-1	67.995	-57.995	10.000
39	1	6	2026-03-02 08:43:44.653794	2026-03-02 08:43:55.167	0.000	0.000	0.000	closed	15.000	POS-1	15.000	0.000	15.000
40	1	6	2026-03-02 08:44:02.628407	\N	0.000	0.000	0.000	open	20.000	POS-1	\N	0.000	\N
41	2	2	2026-03-04 18:18:53.545384	\N	0.000	0.000	0.000	open	1000.000	T1	\N	\N	\N
\.


--
-- Data for Name: stock_transfer_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_transfer_lines (id, transfer_id, variant_id, qty) FROM stdin;
\.


--
-- Data for Name: stock_transfers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_transfers (id, from_location_id, to_location_id, status, notes, created_by, created_at, approved_at) FROM stdin;
1	6	4	draft	\N	6	2026-03-04 17:47:30.925029	\N
\.


--
-- Data for Name: stocktake_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stocktake_items (id, stocktake_id, product_id, system_qty, counted_qty, difference, note) FROM stdin;
1	1	7	750	\N	0	\N
2	1	3	5	\N	0	\N
3	1	1	4	\N	0	\N
4	1	8	1	\N	0	\N
5	2	3	20	\N	0	\N
6	2	1	3	\N	0	\N
7	3	7	750	\N	0	\N
8	3	3	5	\N	0	\N
9	3	1	4	\N	0	\N
10	3	8	1	\N	0	\N
\.


--
-- Data for Name: stocktakes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stocktakes (id, branch_id, location_id, status, note, total_items, matched_items, surplus_items, shortage_items, created_by, approved_by, created_at, completed_at) FROM stdin;
1	1	2	draft	\N	4	0	0	0	6	\N	2026-03-02 13:01:49.700051	\N
2	2	4	draft	\N	2	0	0	0	6	\N	2026-03-03 13:45:42.323412	\N
3	1	2	draft	\N	4	0	0	0	6	\N	2026-03-04 17:47:51.835599	\N
\.


--
-- Data for Name: supplier_ocr_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_ocr_templates (id, supplier_id, invoice_no_pattern, date_pattern, table_start_keyword, column_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, name, phone, email, address, city, tax_no, cr_no, notes, active, created_at) FROM stdin;
1	مورد عام	\N	\N	\N	\N	\N	\N	\N	t	2026-03-02 05:41:05.596106
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, password, name, role, branch_id, is_active, terminal_name, pin, phone, salary, salary_type, commission_rate, ui_language) FROM stdin;
7	test_cashier	$2b$10$ANrQ3ZBYFk6FiNlSqGI3CeqZLIeJriw6SuOk.6To7CWvL5/Chsmam	كاشير تجريبي	cashier	1	t	POS-2	\N	\N	0.000	monthly	0.00	ar
1	mariam	$2b$10$l5qZUiHlwJiuTEA4WEEYRO0bB3ibZYLTpfWnlnC2Awa2xsgHfIBWW	مريم	cashier	2	t	T2	\N	\N	0.000	monthly	0.00	ar
2	ahmed	$2b$10$OK0E9oMQxXVjZ9UqjrjDHumoDJO6/j8MOPFApR4A/pqP4VXA7FXvq	أحمد	employee	2	t	T1	\N	\N	0.000	monthly	0.00	ar
3	fatma	$2b$10$AZpx33TP8lEQLHCVIFZKNeLbIT/HxJVTKPLcMJQ464Q2G3hcCNouC	فاطمة	cashier	1	t	T1	\N	\N	0.000	monthly	0.00	ar
4	noura	$2b$10$GnYTqpmpjv9xTSvTIiqAqeCHTADEpdGcfffxpTCNg9bvaIDGLJh2e	نورة	cashier	2	t	T1	\N	\N	0.000	monthly	0.00	ar
5	huda	$2b$10$nMKbDIB6wpf60flgUqW5sO7dbMqvTkuYsDoEijNmrv6QqiTNeXUsW	هدى	cashier	3	t	T1	\N	\N	0.000	monthly	0.00	ar
8	cashier1	$2b$10$Kz4yS3fM4Or4B0IS0P.x5.Co2ntGyZJQyatNaQfQB2eBqxYPVZ2EW	كاشير١	cashier	1	t	POS-1	\N	\N	0.000	monthly	0.00	ar
9	cashier1_test	$2b$10$pF3n2WQeI74Wpbjoxk6KNOkW.n0gjkqf0TIXPRHVr/ec6Rns1c3jm	كاشير١	cashier	1	t	POS-1	\N	\N	0.000	monthly	0.00	ar
6	owner	$2b$10$z5mg6cFGq9Pu3vdTRzw0lO2hPGncG3.rf9auOGsL6dIyfvF.yJ6Gi	المالك	owner	1	t	POS-1	\N	\N	0.000	monthly	0.00	ar
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warehouses (id, name, branch_id, is_main) FROM stdin;
1	المخزن الرئيسي	1	t
2	مخزن فرع لوى	1	f
3	مخزن فرع شناص	2	f
4	مخزن الفرع الثالث	3	f
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 11, true);


--
-- Name: bank_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bank_ledger_id_seq', 6, true);


--
-- Name: branches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.branches_id_seq', 3, true);


--
-- Name: cash_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cash_ledger_id_seq', 17, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_id_seq', 5, true);


--
-- Name: cities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cities_id_seq', 6, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customers_id_seq', 4, true);


--
-- Name: employee_advances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_advances_id_seq', 1, true);


--
-- Name: employee_deductions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_deductions_id_seq', 1, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employees_id_seq', 1, false);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expenses_id_seq', 9, true);


--
-- Name: inventory_adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_adjustments_id_seq', 1, false);


--
-- Name: inventory_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_balances_id_seq', 17, true);


--
-- Name: inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_id_seq', 24, true);


--
-- Name: inventory_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_ledger_id_seq', 17, true);


--
-- Name: inventory_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_transactions_id_seq', 40, true);


--
-- Name: inventory_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_transfers_id_seq', 1, false);


--
-- Name: location_inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.location_inventory_id_seq', 38, true);


--
-- Name: location_transfer_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.location_transfer_items_id_seq', 6, true);


--
-- Name: location_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.location_transfers_id_seq', 16, true);


--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.locations_id_seq', 7, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_items_id_seq', 4, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_id_seq', 21, true);


--
-- Name: payroll_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_details_id_seq', 12, true);


--
-- Name: payroll_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_runs_id_seq', 1, true);


--
-- Name: product_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_variants_id_seq', 62, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 64, true);


--
-- Name: purchase_extra_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_extra_costs_id_seq', 1, false);


--
-- Name: purchase_invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_invoices_id_seq', 8, true);


--
-- Name: purchase_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_items_id_seq', 63, true);


--
-- Name: sale_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sale_items_id_seq', 13, true);


--
-- Name: sale_return_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sale_return_items_id_seq', 1, false);


--
-- Name: sale_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sale_returns_id_seq', 1, false);


--
-- Name: sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_id_seq', 46, true);


--
-- Name: shifts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shifts_id_seq', 41, true);


--
-- Name: stock_transfer_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_transfer_lines_id_seq', 1, false);


--
-- Name: stock_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_transfers_id_seq', 1, true);


--
-- Name: stocktake_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stocktake_items_id_seq', 10, true);


--
-- Name: stocktakes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stocktakes_id_seq', 3, true);


--
-- Name: supplier_ocr_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplier_ocr_templates_id_seq', 1, false);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 9, true);


--
-- Name: warehouses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warehouses_id_seq', 4, true);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: bank_ledger bank_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_ledger
    ADD CONSTRAINT bank_ledger_pkey PRIMARY KEY (id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: cash_ledger cash_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_ledger
    ADD CONSTRAINT cash_ledger_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: cities cities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT cities_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: employee_advances employee_advances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_advances
    ADD CONSTRAINT employee_advances_pkey PRIMARY KEY (id);


--
-- Name: employee_deductions employee_deductions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_deductions
    ADD CONSTRAINT employee_deductions_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: inventory_adjustments inventory_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_adjustments
    ADD CONSTRAINT inventory_adjustments_pkey PRIMARY KEY (id);


--
-- Name: inventory_balances inventory_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_balances
    ADD CONSTRAINT inventory_balances_pkey PRIMARY KEY (id);


--
-- Name: inventory_ledger inventory_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_ledger
    ADD CONSTRAINT inventory_ledger_pkey PRIMARY KEY (id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (id);


--
-- Name: inventory_transactions inventory_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_pkey PRIMARY KEY (id);


--
-- Name: inventory_transfers inventory_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transfers
    ADD CONSTRAINT inventory_transfers_pkey PRIMARY KEY (id);


--
-- Name: location_inventory location_inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_inventory
    ADD CONSTRAINT location_inventory_pkey PRIMARY KEY (id);


--
-- Name: location_transfer_items location_transfer_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_transfer_items
    ADD CONSTRAINT location_transfer_items_pkey PRIMARY KEY (id);


--
-- Name: location_transfers location_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_transfers
    ADD CONSTRAINT location_transfers_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payroll_details payroll_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_details
    ADD CONSTRAINT payroll_details_pkey PRIMARY KEY (id);


--
-- Name: payroll_runs payroll_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_runs
    ADD CONSTRAINT payroll_runs_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_barcode_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_barcode_unique UNIQUE (barcode);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_sku_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_sku_unique UNIQUE (sku);


--
-- Name: products products_barcode_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_barcode_unique UNIQUE (barcode);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchase_extra_costs purchase_extra_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_extra_costs
    ADD CONSTRAINT purchase_extra_costs_pkey PRIMARY KEY (id);


--
-- Name: purchase_invoices purchase_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_pkey PRIMARY KEY (id);


--
-- Name: purchase_items purchase_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_pkey PRIMARY KEY (id);


--
-- Name: sale_items sale_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_pkey PRIMARY KEY (id);


--
-- Name: sale_return_items sale_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_return_items
    ADD CONSTRAINT sale_return_items_pkey PRIMARY KEY (id);


--
-- Name: sale_returns sale_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_returns
    ADD CONSTRAINT sale_returns_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: shifts shifts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shifts
    ADD CONSTRAINT shifts_pkey PRIMARY KEY (id);


--
-- Name: stock_transfer_lines stock_transfer_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfer_lines
    ADD CONSTRAINT stock_transfer_lines_pkey PRIMARY KEY (id);


--
-- Name: stock_transfers stock_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_pkey PRIMARY KEY (id);


--
-- Name: stocktake_items stocktake_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stocktake_items
    ADD CONSTRAINT stocktake_items_pkey PRIMARY KEY (id);


--
-- Name: stocktakes stocktakes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stocktakes
    ADD CONSTRAINT stocktakes_pkey PRIMARY KEY (id);


--
-- Name: supplier_ocr_templates supplier_ocr_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_ocr_templates
    ADD CONSTRAINT supplier_ocr_templates_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_name_unique UNIQUE (name);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: uq_location_product; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_location_product ON public.location_inventory USING btree (location_id, product_id);


--
-- Name: orders bi_orders_set_order_number; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER bi_orders_set_order_number BEFORE INSERT ON public.orders FOR EACH ROW EXECUTE FUNCTION public.trg_orders_set_order_number();


--
-- Name: sales sales_set_invoice_number; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER sales_set_invoice_number BEFORE INSERT ON public.sales FOR EACH ROW EXECUTE FUNCTION public.trg_sales_set_invoice_number();


--
-- Name: orders trg_orders_set_order_number; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_orders_set_order_number BEFORE INSERT ON public.orders FOR EACH ROW EXECUTE FUNCTION public.trg_orders_set_order_number();


--
-- Name: sale_items trg_sale_items_apply_inventory; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sale_items_apply_inventory AFTER INSERT OR DELETE OR UPDATE ON public.sale_items FOR EACH ROW EXECUTE FUNCTION public.sale_items_apply_inventory_and_update_sale();


--
-- Name: sale_items trg_sale_items_set_total; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sale_items_set_total BEFORE INSERT OR UPDATE ON public.sale_items FOR EACH ROW EXECUTE FUNCTION public.sale_items_set_total();


--
-- Name: expenses validate_expense_shift; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER validate_expense_shift BEFORE INSERT ON public.expenses FOR EACH ROW EXECUTE FUNCTION public.trg_validate_expense_shift();


--
-- Name: audit_log audit_log_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: audit_log audit_log_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: bank_ledger bank_ledger_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_ledger
    ADD CONSTRAINT bank_ledger_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: bank_ledger bank_ledger_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_ledger
    ADD CONSTRAINT bank_ledger_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: bank_ledger bank_ledger_shift_id_shifts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_ledger
    ADD CONSTRAINT bank_ledger_shift_id_shifts_id_fk FOREIGN KEY (shift_id) REFERENCES public.shifts(id);


--
-- Name: cash_ledger cash_ledger_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_ledger
    ADD CONSTRAINT cash_ledger_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: cash_ledger cash_ledger_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_ledger
    ADD CONSTRAINT cash_ledger_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: cash_ledger cash_ledger_shift_id_shifts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_ledger
    ADD CONSTRAINT cash_ledger_shift_id_shifts_id_fk FOREIGN KEY (shift_id) REFERENCES public.shifts(id);


--
-- Name: cities cities_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT cities_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: employee_advances employee_advances_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_advances
    ADD CONSTRAINT employee_advances_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: employee_advances employee_advances_employee_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_advances
    ADD CONSTRAINT employee_advances_employee_id_users_id_fk FOREIGN KEY (employee_id) REFERENCES public.users(id);


--
-- Name: employee_advances employee_advances_settled_in_payroll_id_payroll_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_advances
    ADD CONSTRAINT employee_advances_settled_in_payroll_id_payroll_runs_id_fk FOREIGN KEY (settled_in_payroll_id) REFERENCES public.payroll_runs(id);


--
-- Name: employee_deductions employee_deductions_applied_in_payroll_id_payroll_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_deductions
    ADD CONSTRAINT employee_deductions_applied_in_payroll_id_payroll_runs_id_fk FOREIGN KEY (applied_in_payroll_id) REFERENCES public.payroll_runs(id);


--
-- Name: employee_deductions employee_deductions_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_deductions
    ADD CONSTRAINT employee_deductions_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: employee_deductions employee_deductions_employee_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_deductions
    ADD CONSTRAINT employee_deductions_employee_id_users_id_fk FOREIGN KEY (employee_id) REFERENCES public.users(id);


--
-- Name: employees employees_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: expenses expenses_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: expenses expenses_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: expenses expenses_shift_id_shifts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_shift_id_shifts_id_fk FOREIGN KEY (shift_id) REFERENCES public.shifts(id);


--
-- Name: inventory_adjustments inventory_adjustments_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_adjustments
    ADD CONSTRAINT inventory_adjustments_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: inventory_adjustments inventory_adjustments_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_adjustments
    ADD CONSTRAINT inventory_adjustments_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: inventory_adjustments inventory_adjustments_location_id_locations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_adjustments
    ADD CONSTRAINT inventory_adjustments_location_id_locations_id_fk FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: inventory_adjustments inventory_adjustments_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_adjustments
    ADD CONSTRAINT inventory_adjustments_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: inventory_adjustments inventory_adjustments_stocktake_id_stocktakes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_adjustments
    ADD CONSTRAINT inventory_adjustments_stocktake_id_stocktakes_id_fk FOREIGN KEY (stocktake_id) REFERENCES public.stocktakes(id);


--
-- Name: inventory_balances inventory_balances_location_id_locations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_balances
    ADD CONSTRAINT inventory_balances_location_id_locations_id_fk FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: inventory_balances inventory_balances_variant_id_product_variants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_balances
    ADD CONSTRAINT inventory_balances_variant_id_product_variants_id_fk FOREIGN KEY (variant_id) REFERENCES public.product_variants(id);


--
-- Name: inventory_ledger inventory_ledger_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_ledger
    ADD CONSTRAINT inventory_ledger_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: inventory_ledger inventory_ledger_location_id_locations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_ledger
    ADD CONSTRAINT inventory_ledger_location_id_locations_id_fk FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: inventory_ledger inventory_ledger_variant_id_product_variants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_ledger
    ADD CONSTRAINT inventory_ledger_variant_id_product_variants_id_fk FOREIGN KEY (variant_id) REFERENCES public.product_variants(id);


--
-- Name: inventory inventory_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: inventory_transactions inventory_transactions_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: inventory_transactions inventory_transactions_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: inventory_transactions inventory_transactions_from_location_id_locations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_from_location_id_locations_id_fk FOREIGN KEY (from_location_id) REFERENCES public.locations(id);


--
-- Name: inventory_transactions inventory_transactions_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: inventory_transactions inventory_transactions_to_location_id_locations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_to_location_id_locations_id_fk FOREIGN KEY (to_location_id) REFERENCES public.locations(id);


--
-- Name: inventory_transfers inventory_transfers_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transfers
    ADD CONSTRAINT inventory_transfers_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: inventory_transfers inventory_transfers_from_warehouse_id_warehouses_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transfers
    ADD CONSTRAINT inventory_transfers_from_warehouse_id_warehouses_id_fk FOREIGN KEY (from_warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: inventory_transfers inventory_transfers_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transfers
    ADD CONSTRAINT inventory_transfers_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: inventory_transfers inventory_transfers_to_warehouse_id_warehouses_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_transfers
    ADD CONSTRAINT inventory_transfers_to_warehouse_id_warehouses_id_fk FOREIGN KEY (to_warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: inventory inventory_warehouse_id_warehouses_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_warehouse_id_warehouses_id_fk FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: location_inventory location_inventory_location_id_locations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_inventory
    ADD CONSTRAINT location_inventory_location_id_locations_id_fk FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: location_inventory location_inventory_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_inventory
    ADD CONSTRAINT location_inventory_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: location_transfer_items location_transfer_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_transfer_items
    ADD CONSTRAINT location_transfer_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: location_transfer_items location_transfer_items_transfer_id_location_transfers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_transfer_items
    ADD CONSTRAINT location_transfer_items_transfer_id_location_transfers_id_fk FOREIGN KEY (transfer_id) REFERENCES public.location_transfers(id);


--
-- Name: location_transfers location_transfers_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_transfers
    ADD CONSTRAINT location_transfers_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: location_transfers location_transfers_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_transfers
    ADD CONSTRAINT location_transfers_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: location_transfers location_transfers_from_location_id_locations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_transfers
    ADD CONSTRAINT location_transfers_from_location_id_locations_id_fk FOREIGN KEY (from_location_id) REFERENCES public.locations(id);


--
-- Name: location_transfers location_transfers_to_location_id_locations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_transfers
    ADD CONSTRAINT location_transfers_to_location_id_locations_id_fk FOREIGN KEY (to_location_id) REFERENCES public.locations(id);


--
-- Name: locations locations_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: order_items order_items_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: order_items order_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: orders orders_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: orders orders_employee_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_employee_id_users_id_fk FOREIGN KEY (employee_id) REFERENCES public.users(id);


--
-- Name: orders orders_shift_id_shifts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_shift_id_shifts_id_fk FOREIGN KEY (shift_id) REFERENCES public.shifts(id);


--
-- Name: payroll_details payroll_details_employee_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_details
    ADD CONSTRAINT payroll_details_employee_id_users_id_fk FOREIGN KEY (employee_id) REFERENCES public.users(id);


--
-- Name: payroll_details payroll_details_payroll_id_payroll_runs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_details
    ADD CONSTRAINT payroll_details_payroll_id_payroll_runs_id_fk FOREIGN KEY (payroll_id) REFERENCES public.payroll_runs(id);


--
-- Name: payroll_runs payroll_runs_approved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_runs
    ADD CONSTRAINT payroll_runs_approved_by_users_id_fk FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: payroll_runs payroll_runs_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_runs
    ADD CONSTRAINT payroll_runs_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: product_variants product_variants_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: products products_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: products products_category_id_categories_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_categories_id_fk FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: purchase_extra_costs purchase_extra_costs_purchase_invoice_id_purchase_invoices_id_f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_extra_costs
    ADD CONSTRAINT purchase_extra_costs_purchase_invoice_id_purchase_invoices_id_f FOREIGN KEY (purchase_invoice_id) REFERENCES public.purchase_invoices(id);


--
-- Name: purchase_invoices purchase_invoices_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: purchase_invoices purchase_invoices_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: purchase_invoices purchase_invoices_supplier_id_suppliers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_supplier_id_suppliers_id_fk FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: purchase_items purchase_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: purchase_items purchase_items_purchase_id_purchase_invoices_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_purchase_id_purchase_invoices_id_fk FOREIGN KEY (purchase_id) REFERENCES public.purchase_invoices(id);


--
-- Name: sale_items sale_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: sale_items sale_items_sale_id_sales_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_sale_id_sales_id_fk FOREIGN KEY (sale_id) REFERENCES public.sales(id);


--
-- Name: sale_return_items sale_return_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_return_items
    ADD CONSTRAINT sale_return_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: sale_return_items sale_return_items_return_id_sale_returns_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_return_items
    ADD CONSTRAINT sale_return_items_return_id_sale_returns_id_fk FOREIGN KEY (return_id) REFERENCES public.sale_returns(id);


--
-- Name: sale_return_items sale_return_items_sale_item_id_sale_items_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_return_items
    ADD CONSTRAINT sale_return_items_sale_item_id_sale_items_id_fk FOREIGN KEY (sale_item_id) REFERENCES public.sale_items(id);


--
-- Name: sale_returns sale_returns_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_returns
    ADD CONSTRAINT sale_returns_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: sale_returns sale_returns_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_returns
    ADD CONSTRAINT sale_returns_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: sale_returns sale_returns_sale_id_sales_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_returns
    ADD CONSTRAINT sale_returns_sale_id_sales_id_fk FOREIGN KEY (sale_id) REFERENCES public.sales(id);


--
-- Name: sale_returns sale_returns_shift_id_shifts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_returns
    ADD CONSTRAINT sale_returns_shift_id_shifts_id_fk FOREIGN KEY (shift_id) REFERENCES public.shifts(id);


--
-- Name: sales sales_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: sales sales_cashier_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_cashier_id_users_id_fk FOREIGN KEY (cashier_id) REFERENCES public.users(id);


--
-- Name: sales sales_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: sales sales_shift_id_shifts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_shift_id_shifts_id_fk FOREIGN KEY (shift_id) REFERENCES public.shifts(id);


--
-- Name: shifts shifts_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shifts
    ADD CONSTRAINT shifts_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: shifts shifts_cashier_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shifts
    ADD CONSTRAINT shifts_cashier_id_users_id_fk FOREIGN KEY (cashier_id) REFERENCES public.users(id);


--
-- Name: stock_transfer_lines stock_transfer_lines_transfer_id_stock_transfers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfer_lines
    ADD CONSTRAINT stock_transfer_lines_transfer_id_stock_transfers_id_fk FOREIGN KEY (transfer_id) REFERENCES public.stock_transfers(id);


--
-- Name: stock_transfer_lines stock_transfer_lines_variant_id_product_variants_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfer_lines
    ADD CONSTRAINT stock_transfer_lines_variant_id_product_variants_id_fk FOREIGN KEY (variant_id) REFERENCES public.product_variants(id);


--
-- Name: stock_transfers stock_transfers_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: stock_transfers stock_transfers_from_location_id_locations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_from_location_id_locations_id_fk FOREIGN KEY (from_location_id) REFERENCES public.locations(id);


--
-- Name: stock_transfers stock_transfers_to_location_id_locations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_to_location_id_locations_id_fk FOREIGN KEY (to_location_id) REFERENCES public.locations(id);


--
-- Name: stocktake_items stocktake_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stocktake_items
    ADD CONSTRAINT stocktake_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stocktake_items stocktake_items_stocktake_id_stocktakes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stocktake_items
    ADD CONSTRAINT stocktake_items_stocktake_id_stocktakes_id_fk FOREIGN KEY (stocktake_id) REFERENCES public.stocktakes(id);


--
-- Name: stocktakes stocktakes_approved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stocktakes
    ADD CONSTRAINT stocktakes_approved_by_users_id_fk FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: stocktakes stocktakes_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stocktakes
    ADD CONSTRAINT stocktakes_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: stocktakes stocktakes_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stocktakes
    ADD CONSTRAINT stocktakes_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: stocktakes stocktakes_location_id_locations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stocktakes
    ADD CONSTRAINT stocktakes_location_id_locations_id_fk FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: supplier_ocr_templates supplier_ocr_templates_supplier_id_suppliers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_ocr_templates
    ADD CONSTRAINT supplier_ocr_templates_supplier_id_suppliers_id_fk FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: users users_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: warehouses warehouses_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 6pfgwZJVcd6FJ5UYZbaTGNuv53oLTbJ1CTxT0yCUSQd3meUbUaZeWFDHi89yIvU

